# data/ - where the UBFC-rPPG dataset goes

Download from the official page (terms of use and citation request are there):
https://sites.google.com/view/ybenezeth/ubfcrppg

Copy the files in so the layout is exactly:

    data/UBFC-rPPG/DATASET_2/subject1/vid.avi
    data/UBFC-rPPG/DATASET_2/subject1/ground_truth.txt
    data/UBFC-rPPG/DATASET_2/subject2/...            (42 subjects)
    data/UBFC-rPPG/DATASET_1/subject1/vid.avi
    data/UBFC-rPPG/DATASET_1/subject1/gtdump.xmp     (8 subjects)

Then run from the project root, with no other arguments:

    python validation/evaluate_ubfc.py --method pos --split test   # DATASET_2 -> results/dataset2
    python validation/evaluate_ubfc.py --dataset 1          # DATASET_1 -> results/dataset1

Results (CSV files, Bland-Altman plot) are written to `results/`. Those files are
the only source of the heart-rate numbers in the paper.

The videos are not committed (see .gitignore). Redistributing the dataset is governed
by its own terms, so keep it out of public repositories and out of the shared zip
unless the terms allow it.

---

# MCD-rPPG (recommended main dataset for heart rate)

Open license (CC-BY-4.0), 600 subjects, each filmed before (rest) and after physical
activity with a synchronised PPG signal. That matches the rest / exercise conditions of the
paper without recruiting anyone. https://huggingface.co/datasets/kyegorov/mcd_rppg

Get a subset (the full dataset is huge):

    pip install huggingface_hub
    python validation/download_mcd_subset.py --dry-run     # size first
    python validation/download_mcd_subset.py --n 20        # -> data/MCD-rPPG/

or copy files in by hand so you have:

    data/MCD-rPPG/video/1020_FullHDwebcam_before.avi
    data/MCD-rPPG/video/1020_FullHDwebcam_after.avi
    data/MCD-rPPG/ppg_sync/1020_FullHDwebcam_before.txt
    data/MCD-rPPG/ppg_sync/1020_FullHDwebcam_after.txt

Then:  python validation/evaluate_mcd.py        (results -> results/mcd/)

Cite: Egorov et al., "Gaze into the Heart: A Multi-View Video Dataset for rPPG and Health
Biomarkers Estimation", ACM Multimedia 2025, doi:10.1145/3746027.3758255.
