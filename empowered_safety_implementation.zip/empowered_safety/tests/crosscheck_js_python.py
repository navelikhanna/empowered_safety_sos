#!/usr/bin/env python3
"""Checks that validation/rppg_core.py::calculate_heart_rate_pos (used by the
offline evaluation) gives the same BPM as the shipped POS calculateHeartRate()
in script.js, on synthetic RGB windows with regular AND jittered frame timing.

It also reports how well the estimator recovers the true synthetic rate, and
shows that windows shorter than ~14 s are rejected.

Needs: node, numpy.   Run from the project root:  python tests/crosscheck_js_python.py
"""
import json, os, subprocess, sys, tempfile
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "validation"))
from rppg_core import calculate_heart_rate_pos  # noqa: E402


def rgb_window(hr, fps, seconds=15.5, jitter=0.0, noise=0.3, drift=0.4, seed=0):
    """Synthetic face-ROI colour traces: pulse (strongest in G) + slow drift +
    noise, sampled at a nominal fps with optional timing jitter (fraction)."""
    rng = np.random.default_rng(seed)
    t, tt = [], 0.0
    while tt < seconds * 1000:
        t.append(tt)
        tt += (1000.0 / fps) * (1 + jitter * (rng.random() * 2 - 1))
    t = np.array(t)
    ph = 2 * np.pi * (hr / 60.0) * t / 1000.0
    d = drift * t / 1000.0
    r = 150 + d + 0.15 * np.sin(ph) + noise * (rng.random(len(t)) - .5)
    g = 100 + 0.6 * d + 0.60 * np.sin(ph + 0.3) + noise * (rng.random(len(t)) - .5)
    b = 90 + 0.5 * d + 0.30 * np.sin(ph) + noise * (rng.random(len(t)) - .5)
    return dict(t_ms=(1e9 + t).tolist(), r=r.tolist(), g=g.tolist(), b=b.tolist())


def main():
    cases, meta = [], []
    for fps in (15, 20, 25, 30):
        for jitter in (0.0, 0.25):
            for hr in (50, 60, 72, 90, 110, 130, 150, 170):
                for seed in range(3):
                    cases.append(rgb_window(hr, fps, jitter=jitter, seed=seed))
                    meta.append((fps, jitter, hr, seed))
    short = rgb_window(72, 30, seconds=8.0)          # must be rejected
    cases.append(short); meta.append((30, 0.0, 72, -1))

    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        json.dump(cases, f); path = f.name
    out = subprocess.run(["node", os.path.join(ROOT, "tests", "js_hr_harness.js"), path],
                         capture_output=True, text=True, check=True).stdout
    js = json.loads(out); os.unlink(path)

    max_diff, rows = 0.0, []
    for c, m, j in zip(cases, meta, js):
        p = calculate_heart_rate_pos(c["r"], c["g"], c["b"], c["t_ms"])
        max_diff = max(max_diff, abs(p - j))
        rows.append((m, j, p))
    n_main = len(cases) - 1
    print(f"cases: {len(cases)}   max |JS - Python| = {max_diff:.6f} BPM")
    errs = [abs(j - m[2]) for m, j, p in rows[:n_main] if j > 0]
    print(f"JS estimate vs true synthetic HR: MAE={np.mean(errs):.2f} BPM over {len(errs)}/{n_main} windows "
          f"(max error {np.max(errs):.2f})")
    for hr in (50, 130, 170):
        v = [j for m, j, p in rows[:n_main] if m[2] == hr and m[0] == 30 and m[1] == 0.25]
        print(f"  true {hr:3d} BPM @30 fps, jittered timing -> JS reads {np.round(v, 1).tolist()}")
    print(f"  8 s window (too short) -> JS {js[-1]}, Python {rows[-1][2]}  (both must be 0)")
    ok = max_diff < 1e-3 and js[-1] == 0 and rows[-1][2] == 0
    print("PASS: JS and Python POS agree" if ok else "FAIL: JS and Python POS differ")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
