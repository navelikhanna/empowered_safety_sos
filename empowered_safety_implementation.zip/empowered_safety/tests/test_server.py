"""Backend tests with Twilio mocked (no SMS is sent, no credentials needed).

    python -m unittest tests.test_server -v        (from the project root)

Checks that every trigger source reaches the same dispatch path and is logged,
that bad input is rejected, and that Twilio failures are logged as errors.
This is a software test of the backend pipeline; it is not a replacement for
real end-to-end SMS trials on real devices/browsers.
"""
import csv, importlib, os, sys, tempfile, types, unittest
from unittest import mock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def _install_stubs_if_missing():
    """Let the tests run where twilio / flask_cors / dotenv are not installed."""
    try:
        import twilio.rest  # noqa: F401
    except Exception:
        tw = types.ModuleType("twilio"); rest = types.ModuleType("twilio.rest")
        rest.Client = mock.MagicMock(); tw.rest = rest
        sys.modules.update({"twilio": tw, "twilio.rest": rest})
    try:
        import flask_cors  # noqa: F401
    except Exception:
        fc = types.ModuleType("flask_cors"); fc.CORS = lambda app, **kw: app
        sys.modules["flask_cors"] = fc
    try:
        import dotenv  # noqa: F401
    except Exception:
        d = types.ModuleType("dotenv"); d.load_dotenv = lambda *a, **k: None
        sys.modules["dotenv"] = d


class SosServerTests(unittest.TestCase):
    def setUp(self):
        _install_stubs_if_missing()
        self.tmp = tempfile.TemporaryDirectory()
        os.environ.update(TWILIO_ACCOUNT_SID="ACtest", TWILIO_AUTH_TOKEN="x",
                          TWILIO_PHONE_NUMBER="+15550000000", SOS_LOG_DIR=self.tmp.name)
        sys.modules.pop("sos_server", None)
        self.srv = importlib.import_module("sos_server")
        self.srv.client = mock.MagicMock()
        self.srv.client.messages.create.return_value = types.SimpleNamespace(sid="SMfake")
        self.c = self.srv.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def rows(self):
        with open(self.srv.LOG_FILE, newline="") as f:
            return list(csv.DictReader(f))

    def post(self, **over):
        body = dict(number="+919876543210", latitude=26.9, longitude=75.8,
                    accuracy_m=35, trigger_source="manual")
        body.update(over)
        return self.c.post("/sos", json=body)

    def test_all_trigger_sources_dispatch_and_log(self):
        for src in ("manual", "voice", "hr_fusion", "hr_confirmed", "hr_timeout"):
            r = self.post(trigger_source=src)
            self.assertEqual(r.status_code, 200, src)
            self.assertIn("server_latency_ms", r.get_json())
        got = [row["trigger_source"] for row in self.rows()]
        self.assertEqual(got, ["manual", "voice", "hr_fusion", "hr_confirmed", "hr_timeout"])
        self.assertTrue(all(row["status"] == "success" for row in self.rows()))
        self.assertEqual(self.srv.client.messages.create.call_count, 5)

    def test_message_contains_maps_link(self):
        self.post()
        body = self.srv.client.messages.create.call_args.kwargs["body"]
        self.assertIn("maps.google.com/?q=26.9,75.8", body)

    def test_rejects_bad_number(self):
        for bad in ("9876543210", "+0123456789", "+12", "abc", None, 12345678901):
            r = self.post(number=bad)
            self.assertEqual(r.status_code, 400, repr(bad))
        self.srv.client.messages.create.assert_not_called()

    def test_rejects_bad_coordinates(self):
        for lat, lon in ((None, 75), (91, 75), (26, 181), ("26", "75"), (True, 1)):
            self.assertEqual(self.post(latitude=lat, longitude=lon).status_code, 400, (lat, lon))
        self.srv.client.messages.create.assert_not_called()

    def test_twilio_failure_is_logged_not_swallowed(self):
        self.srv.client.messages.create.side_effect = RuntimeError("boom")
        r = self.post()
        self.assertEqual(r.status_code, 500)
        row = self.rows()[-1]
        self.assertEqual(row["status"], "error")
        self.assertIn("boom", row["error"])

    def test_accuracy_is_logged(self):
        self.post(accuracy_m=1234)
        self.assertEqual(self.rows()[-1]["geo_accuracy_m"], "1234")


if __name__ == "__main__":
    unittest.main()
