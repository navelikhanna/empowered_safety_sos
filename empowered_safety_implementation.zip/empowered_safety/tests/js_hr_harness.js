// Loads the REAL script.js in a stubbed browser context and runs
// calculateHeartRate() (POS) on RGB windows supplied as JSON, so the Python port
// (validation/rppg_core.py) can be checked against the code that actually ships.
//   node tests/js_hr_harness.js signals.json  ->  JSON array of BPM
const fs = require('fs');
const vm = require('vm');
const path = require('path');

const stubEl = () => ({ addEventListener() {}, style: {}, classList: { add() {}, remove() {} } });
const ctx = {
  console: { log() {}, error() {}, warn() {} },
  document: { addEventListener() {}, getElementById: stubEl, createElement: stubEl, body: { appendChild() {} } },
  localStorage: { getItem: () => null, setItem() {} },
  navigator: {},
  performance: { now: () => Date.now() },
  window: {}, Date, Math, JSON, Promise, setTimeout, setInterval, clearInterval,
  requestAnimationFrame() {}, cancelAnimationFrame() {},
  alert() {}, confirm: () => true, fetch: () => Promise.reject(new Error('stub')),
  URL, Blob: class {},
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'script.js'), 'utf8'), ctx);

const cases = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const out = cases.map(c => {
  // c.t_ms: frame timestamps (ms, possibly irregular); c.r/g/b: per-frame ROI means
  const samples = c.t_ms.map((t, i) => ({ r: c.r[i], g: c.g[i], b: c.b[i], timestamp: t, motion: 0 }));
  return ctx.calculateHeartRate(samples);
});
process.stdout.write(JSON.stringify(out));
