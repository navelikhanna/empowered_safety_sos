import os
import csv
import json
import time
import re
import platform
from datetime import datetime, timezone
from importlib.metadata import version, PackageNotFoundError

from flask import Flask, request, jsonify
from flask_cors import CORS
from twilio.rest import Client
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# Only the local front-end may call this relay. The previous CORS(app) allowed
# ANY website open in the user's browser to trigger SMS through the owner's
# Twilio account. Override with ALLOWED_ORIGINS="https://a.example,https://b.example".
ALLOWED_ORIGINS = [o.strip() for o in os.environ.get(
    "ALLOWED_ORIGINS", "http://127.0.0.1:8000,http://localhost:8000,http://127.0.0.1:5500,http://localhost:5500").split(",") if o.strip()]
CORS(app, origins=ALLOWED_ORIGINS)

# --- Credentials now come from environment variables (.env), never from source ---
account_sid = os.environ["TWILIO_ACCOUNT_SID"]
auth_token = os.environ["TWILIO_AUTH_TOKEN"]
twilio_number = os.environ["TWILIO_PHONE_NUMBER"]

client = Client(account_sid, auth_token)

LOG_DIR = os.environ.get("SOS_LOG_DIR", "sessions")
LOG_FILE = os.path.join(LOG_DIR, "sos_dispatch_log.csv")
os.makedirs(LOG_DIR, exist_ok=True)


LOG_FIELDS = [
    "timestamp_utc",
    "trigger_source",
    "contact_number",
    "latitude",
    "longitude",
    "geo_accuracy_m",
    "status",
    "twilio_sid",
    "server_latency_ms",
    "error",
]


def _pkg(name):
    try:
        return version(name)
    except PackageNotFoundError:
        return "unknown"


def write_run_metadata():
    """Record the environment that produced a latency log, so the latency
    experiment can be described/reproduced (OS, Python, library versions)."""
    meta = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "flask": _pkg("flask"),
        "twilio": _pkg("twilio"),
        "werkzeug": _pkg("werkzeug"),
        "hostname_hash_note": "hostname intentionally not recorded",
        # Optional, set in .env so the latency experiment's setup is on record:
        "server_location": os.environ.get("SERVER_LOCATION", "not set"),
        "network_note": os.environ.get("NETWORK_NOTE", "not set"),
        "allowed_origins": ALLOWED_ORIGINS,
        "note": "Set SERVER_LOCATION and NETWORK_NOTE (e.g. 'home Wi-Fi, 100 Mbps') in .env.",
    }
    with open(os.path.join(LOG_DIR, "run_metadata.json"), "w") as f:
        json.dump(meta, f, indent=2)


def ensure_log_schema():
    """If an older log with a different header exists, move it aside so new
    columns don't get appended under a stale header."""
    if os.path.isfile(LOG_FILE):
        with open(LOG_FILE, newline="") as f:
            header = next(csv.reader(f), [])
        if header != LOG_FIELDS:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            os.rename(LOG_FILE, os.path.join(LOG_DIR, f"sos_dispatch_log_old_{stamp}.csv"))


def log_dispatch(row):
    """Append one SOS dispatch attempt to a CSV log for later statistical
    analysis (mean/SD latency, success rate with confidence interval, etc.)
    instead of only being visible in server console output."""
    file_exists = os.path.isfile(LOG_FILE)
    with open(LOG_FILE, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


E164_RE = re.compile(r"^\+[1-9]\d{7,14}$")


def _valid_coord(value, limit):
    """Reject non-numeric / out-of-range coordinates (also rejects booleans)."""
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and -limit <= value <= limit)


@app.route('/sos', methods=['POST'])
def send_sos():
    t_start = time.perf_counter()
    data = request.get_json(force=True, silent=True) or {}
    contact_number = data.get("number")
    latitude = data.get("latitude")
    longitude = data.get("longitude")
    accuracy_m = data.get("accuracy_m")
    trigger_source = data.get("trigger_source", "unknown")

    row = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "trigger_source": trigger_source,
        "contact_number": contact_number,
        "latitude": latitude,
        "longitude": longitude,
        "geo_accuracy_m": accuracy_m if accuracy_m is not None else "",
        "status": "error",
        "twilio_sid": "",
        "server_latency_ms": "",
        "error": "",
    }

    if not contact_number:
        row["error"] = "missing contact number"
        log_dispatch(row)
        return jsonify({"status": "error", "message": "No contact number provided"}), 400

    if latitude is None or longitude is None:
        row["error"] = "missing coordinates"
        log_dispatch(row)
        return jsonify({"status": "error", "message": "No location provided"}), 400

    # Format-only checks (not proof the number exists or is reachable).
    if not isinstance(contact_number, str) or not E164_RE.match(contact_number):
        row["error"] = "invalid contact number format"
        log_dispatch(row)
        return jsonify({"status": "error", "message": "Contact number must be in E.164 format"}), 400

    if not (_valid_coord(latitude, 90) and _valid_coord(longitude, 180)):
        row["error"] = "invalid coordinates"
        log_dispatch(row)
        return jsonify({"status": "error", "message": "Invalid coordinates"}), 400

    google_maps_link = f"https://maps.google.com/?q={latitude},{longitude}"

    try:
        message = client.messages.create(
            body=f"SOS Alert: I need help. Location: {google_maps_link}",
            from_=twilio_number,
            to=contact_number,
        )
        row["status"] = "success"
        row["twilio_sid"] = message.sid
        row["server_latency_ms"] = round((time.perf_counter() - t_start) * 1000, 1)
        log_dispatch(row)
        return jsonify({"status": "success", "sid": message.sid,
                        "server_latency_ms": row["server_latency_ms"]}), 200

    except Exception as e:
        row["error"] = str(e)
        row["server_latency_ms"] = round((time.perf_counter() - t_start) * 1000, 1)
        log_dispatch(row)
        return jsonify({"status": "error", "message": str(e),
                        "server_latency_ms": row["server_latency_ms"]}), 500


if __name__ == '__main__':
    ensure_log_schema()
    write_run_metadata()
    # The Werkzeug debugger allows arbitrary code execution, so it is OFF by
    # default. For local development only:  FLASK_DEBUG=1 python sos_server.py
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
