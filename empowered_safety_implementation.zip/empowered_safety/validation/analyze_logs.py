#!/usr/bin/env python3
"""
Turn the app's exported CSV logs into the statistics the reviewers asked for.
Every number is computed from raw trial rows, never typed in.

    python analyze_logs.py --sos sos_dispatch_log.csv --voice voice_trial_log.csv \
                           --hr hr_session_data.csv --out log_stats
Optional:
    --server-log sessions/sos_dispatch_log.csv --truth-lat 26.9124 --truth-lon 75.7873
        compares the logged coordinates with a SURVEYED true position and reports the
        real location error (the browser's own accuracy radius is NOT an error measurement).

SOS      success rate + Wilson 95 % CI; latency mean / SD / median / min / max
         (overall and per trigger source); claimed accuracy radius; geo fix time.
Voice    accuracy per noise condition x intended keyword with Wilson CI;
         pooled accuracy with a cluster bootstrap CI (clusters = session) to
         reflect that trials from one speaker/session are not independent;
         false-trigger rate on negative-control trials; confusion table.
HR       share of failed estimates by condition / motion; paired app-vs-reference
         MAE, bias, SD, 95 % limits of agreement per condition (needs reference rows).
Run it on your own exports and report what it prints.
"""
import argparse
import os
import numpy as np
import pandas as pd


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def cluster_bootstrap_ci(df, correct_col, cluster_col, n=5000, seed=0):
    """CI for pooled accuracy resampling whole clusters (sessions)."""
    groups = [g[correct_col].to_numpy() for _, g in df.groupby(cluster_col)]
    if len(groups) < 2:
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    accs = []
    for _ in range(n):
        pick = rng.integers(0, len(groups), len(groups))
        vals = np.concatenate([groups[i] for i in pick])
        accs.append(vals.mean())
    return tuple(np.percentile(accs, [2.5, 97.5]))


def haversine_m(lat1, lon1, lat2, lon2):
    R = 6371000.0
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dphi, dl = p2 - p1, np.radians(lon2 - lon1)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


def desc(x):
    x = pd.to_numeric(x, errors="coerce").dropna()
    if x.empty:
        return dict(n=0)
    return dict(n=len(x), mean=x.mean(), SD=x.std(ddof=1) if len(x) > 1 else np.nan,
                median=x.median(), min=x.min(), max=x.max())


def analyze_sos(path, out):
    d = pd.read_csv(path)
    rows = []
    for name, g in [("ALL", d)] + [(f"source={s}", g) for s, g in d.groupby("trigger_source")]:
        n = len(g); k = int((g.status == "success").sum())
        lo, hi = wilson(k, n)
        ok = g[g.status == "success"]
        r = dict(group=name, n_attempts=n, n_success=k, success_rate=k / n, CI95_low=lo, CI95_high=hi)
        for col in ("latency_ms", "server_latency_ms", "geo_fix_ms", "geo_accuracy_m"):
            if col in g:
                for key, v in desc(ok[col] if col != "geo_accuracy_m" else g[col]).items():
                    r[f"{col}_{key}"] = v
        rows.append(r)
    res = pd.DataFrame(rows)
    res.to_csv(os.path.join(out, "sos_summary.csv"), index=False)
    print("\n=== SOS dispatch ===")
    print(res.T.to_string(header=False))
    print("NOTE: latency_ms = browser-measured round trip to the backend including the Twilio API "
          "call; it is NOT time-to-handset. Time-to-handset needs the receiving phone's clock.")
    if "net_effective_type" in d:
        print("Network types seen:", d.net_effective_type.fillna("").value_counts().to_dict())


def analyze_geo_truth(server_log, tlat, tlon, out):
    d = pd.read_csv(server_log)
    d = d.dropna(subset=["latitude", "longitude"])
    d["error_m"] = haversine_m(d.latitude, d.longitude, tlat, tlon)
    d.to_csv(os.path.join(out, "geo_error_vs_truth.csv"), index=False)
    e = d.error_m
    print("\n=== Geolocation error vs surveyed position ===")
    print(f"n={len(e)}  mean={e.mean():.1f} m  SD={e.std(ddof=1) if len(e) > 1 else float('nan'):.1f}  "
          f"median={e.median():.1f}  max={e.max():.1f}")
    if "geo_accuracy_m" in d and d.geo_accuracy_m.notna().any():
        cov = (d.error_m <= pd.to_numeric(d.geo_accuracy_m, errors="coerce")).mean()
        print(f"fraction of fixes whose true error <= browser-claimed radius: {cov:.2f} "
              f"(the spec's radius is a 68 % confidence level)")


def analyze_voice(path, out):
    d = pd.read_csv(path).fillna({"matched_keyword": "none"})
    if "expected_keyword" not in d or (d.expected_keyword == "unspecified").all():
        print("\n=== Voice === expected_keyword missing: re-collect with the 'intended' selector.")
        return
    d["error_trial"] = d.matched_keyword.astype(str).str.startswith("error:")
    d["correct"] = (d.matched_keyword == d.expected_keyword) & ~d.error_trial
    rows = []
    for (cond, kw), g in d.groupby(["noise_condition", "expected_keyword"]):
        k, n = int(g.correct.sum()), len(g)
        lo, hi = wilson(k, n)
        rows.append(dict(noise_condition=cond, intended=kw, n=n, correct=k, accuracy=k / n,
                         CI95_low=lo, CI95_high=hi, recognizer_errors=int(g.error_trial.sum()),
                         n_speakers=g.speaker_id.nunique(), n_sessions=g.session_id.nunique()))
    cell = pd.DataFrame(rows)
    pooled = []
    for cond, g in d.groupby("noise_condition"):
        k, n = int(g.correct.sum()), len(g)
        w_lo, w_hi = wilson(k, n)
        c_lo, c_hi = cluster_bootstrap_ci(g, "correct", "session_id")
        pooled.append(dict(noise_condition=cond, n=n, accuracy=k / n, wilson_low=w_lo, wilson_high=w_hi,
                           cluster_boot_low=c_lo, cluster_boot_high=c_hi,
                           n_speakers=g.speaker_id.nunique(), n_sessions=g.session_id.nunique()))
    pooled = pd.DataFrame(pooled)
    # false triggers: negative-control trials that nevertheless matched an SOS keyword
    neg = d[d.expected_keyword == "none"]
    fa = None
    if len(neg):
        k = int(neg.matched_keyword.isin(["help", "emergency"]).sum())
        fa = dict(n_negative_trials=len(neg), false_sos_keyword=k, rate=k / len(neg),
                  CI95=wilson(k, len(neg)))
    conf = pd.crosstab([d.noise_condition, d.expected_keyword], d.matched_keyword)
    cell.to_csv(os.path.join(out, "voice_by_condition_keyword.csv"), index=False)
    pooled.to_csv(os.path.join(out, "voice_pooled.csv"), index=False)
    conf.to_csv(os.path.join(out, "voice_confusion.csv"))
    pd.set_option("display.width", 200, "display.max_columns", 20)
    print("\n=== Voice: by noise condition x intended keyword (Wilson 95 % CI) ===")
    print(cell.round(3).to_string(index=False))
    print("\n=== Voice: pooled per noise condition (Wilson assumes independent trials; "
          "cluster bootstrap resamples sessions) ===")
    print(pooled.round(3).to_string(index=False))
    if fa:
        print(f"\nNegative-control trials: {fa['n_negative_trials']}, false 'help'/'emergency' matches: "
              f"{fa['false_sos_keyword']} (rate {fa['rate']:.3f}, 95% CI "
              f"{fa['CI95'][0]:.3f}-{fa['CI95'][1]:.3f})")
    else:
        print("\nNo negative-control trials (intended: none) were logged - false-positive rate "
              "and keyword confusability cannot be assessed.")
    print("\nConfusion (rows = condition/intended, cols = what the app matched):")
    print(conf.to_string())


def analyze_hr(path, out):
    d = pd.read_csv(path)
    sess = d[d.get("source") == "session_log"] if "source" in d else d
    ref = d[d.get("source") == "reference_log"] if "source" in d else pd.DataFrame()
    print("\n=== Heart rate ===")
    mon = sess[sess.get("phase").isin(["calibration", "monitoring"])] if "phase" in sess else sess
    if len(mon):
        mon = mon.assign(failed=(mon.status == "no_estimate"))
        by = mon.groupby("condition", dropna=False).agg(
            readings=("failed", "size"), failed=("failed", "sum"),
            mean_motion=("motion", "mean"), mean_fps=("fps_achieved", "mean"))
        by["failed_rate"] = by.failed / by.readings
        by.to_csv(os.path.join(out, "hr_failure_by_condition.csv"))
        print(by.round(3).to_string())
    if len(ref):
        ref = ref.assign(app_bpm=pd.to_numeric(ref.app_bpm, errors="coerce"),
                         reference_bpm=pd.to_numeric(ref.reference_bpm, errors="coerce")).dropna(
                             subset=["app_bpm", "reference_bpm"])
        ref["diff"] = ref.app_bpm - ref.reference_bpm
        rows = []
        for cond, g in [("ALL", ref)] + list(ref.groupby("condition")):
            sd = g["diff"].std(ddof=1) if len(g) > 1 else np.nan
            rows.append(dict(condition=cond, n_pairs=len(g), n_subjects=g.subject_id.nunique(),
                             MAE=g["diff"].abs().mean(), bias=g["diff"].mean(), SD_diff=sd,
                             LoA_low=g["diff"].mean() - 1.96 * sd, LoA_high=g["diff"].mean() + 1.96 * sd))
        r = pd.DataFrame(rows)
        r.to_csv(os.path.join(out, "hr_vs_reference.csv"), index=False)
        print("\nApp vs reference device (paired, per condition):")
        print(r.round(2).to_string(index=False))
        print("Pairs from the same subject are not independent; report n_subjects alongside n_pairs.")
    else:
        print("No reference rows logged (use 'Record reference reading' during sessions).")
    ev = sess[sess.get("phase") == "event"] if "phase" in sess else pd.DataFrame()
    if len(ev):
        print("\nAlert events:", ev.status.value_counts().to_dict())


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--sos"); ap.add_argument("--voice"); ap.add_argument("--hr")
    ap.add_argument("--server-log"); ap.add_argument("--truth-lat", type=float)
    ap.add_argument("--truth-lon", type=float); ap.add_argument("--out", default="log_stats")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    if a.sos: analyze_sos(a.sos, a.out)
    if a.server_log and a.truth_lat is not None and a.truth_lon is not None:
        analyze_geo_truth(a.server_log, a.truth_lat, a.truth_lon, a.out)
    if a.voice: analyze_voice(a.voice, a.out)
    if a.hr: analyze_hr(a.hr, a.out)
    if not (a.sos or a.voice or a.hr):
        ap.error("give at least one of --sos / --voice / --hr")
