#!/usr/bin/env python3
"""
*** LEGACY (red-channel peak detection): evaluates the replaced estimator, NOT the POS method now in
script.js. Do not report its numbers as the app's performance. The POS evaluation used in the paper
(--method pos --split test) is validation/evaluate_ubfc.py. This file is the old red-channel script, kept only for the legacy tools. ***

Offline validation of the Empowered Safety rPPG module on the public
UBFC-rPPG dataset (Bobbia et al., 2019, Pattern Recognition Letters).

Why this exists
---------------
The browser app (script.js) estimates heart rate from the red channel of a
forehead ROI found with BlazeFace. Instead of collecting volunteer data
(which needs ethics approval), the same algorithm is run here on pre-recorded,
publicly released videos that come with pulse-oximeter ground truth.

Fidelity to script.js
---------------------
calculate_heart_rate() is a line-by-line port of calculateHeartRate():
  * mean removal, centred moving average (half-window 0.10 s, edge-truncated)
  * local-maximum test over +/-3 neighbours, threshold = 0.3 * max(smoothed)
  * refractory gap > 0.33 s, >= 3 peaks required
  * 10 %-trimmed mean of peak intervals, BPM = 60 / (interval / fps)
  * outputs outside [50, 150] BPM are rejected (returns 0)
Smoothing half-window and refractory gap are defined in seconds and converted
to samples with the frame rate (3 and 10 samples at 30 FPS). The earlier
fixed 5 / 15 samples capped detectable HR near 112 BPM; pass
--legacy-params (or see --sweep) to reproduce that behaviour.
Forehead ROI geometry (x+25 % w, y+5 % h, 50 % w, 25 % h of the face box)
and the rolling 150-frame window evaluated every 3 s also match script.js.

Face detection uses MediaPipe's short-range face detector, which is a BlazeFace
model (the same architecture as the TF.js BlazeFace used in the browser). The
box is not bit-identical to the TF.js output, so state this in the paper.

Expected dataset layout (UBFC-rPPG)
-----------------------------------
DATASET_1/subjectN/vid.avi  + gtdump.xmp
DATASET_2/subjectN/vid.avi  + ground_truth.txt
Pass the folder that contains the subject folders (e.g. .../DATASET_2).

Usage
-----
python evaluate_ubfc.py --root /path/to/DATASET_2 --out results_dataset2
python evaluate_ubfc.py --root /path/to/DATASET_1 --out results_dataset1 --dataset 1
"""
import argparse
import os
import sys
import glob
import numpy as np
import pandas as pd
import cv2

# ---- constants + algorithm port live in rppg_core.py (shared with the synthetic
# motion experiment and the JS<->Python cross-check) ---------------------------
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from rppg_core import (FPS, MIN_BPM, MAX_BPM, WINDOW, MIN_SAMPLES, STEP_SECONDS,  # noqa: E402
                       CALIBRATION_SECONDS, EMERGENCY_THRESHOLD, LOW_BPM_THRESHOLD,
                       DYNAMIC_UPPER_OFFSET, DYNAMIC_LOWER_OFFSET, SUSTAINED_READINGS,
                       SMOOTH_HALF_WINDOW_S, MIN_PEAK_GAP_S, PEAK_THRESHOLD_FRAC, LEGACY,
                       calculate_heart_rate, alert_decision, replay_alert_logic)


# ---- face / ROI ----------------------------------------------------------------
class FaceBox:
    """BlazeFace (MediaPipe) detector; falls back to OpenCV Haar if unavailable."""

    def __init__(self):
        self.mp = None
        try:
            import mediapipe as mp
            self.mp = mp.solutions.face_detection.FaceDetection(
                model_selection=0, min_detection_confidence=0.5)
            self.name = "mediapipe-blazeface"
        except Exception:
            self.haar = cv2.CascadeClassifier(
                cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
            self.name = "opencv-haar (fallback; NOT BlazeFace)"

    def __call__(self, bgr):
        h, w = bgr.shape[:2]
        if self.mp is not None:
            res = self.mp.process(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
            if not res.detections:
                return None
            b = res.detections[0].location_data.relative_bounding_box
            return b.xmin * w, b.ymin * h, b.width * w, b.height * h
        g = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        f = self.haar.detectMultiScale(g, 1.1, 5)
        return tuple(map(float, f[0])) if len(f) else None


def video_info(video_path):
    """(fps, duration_s) of a video file."""
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or FPS
    n = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    cap.release()
    return fps, (n / fps if n else float("nan"))


def extract_signal(video_path, detector, start_s=0.0, max_seconds=None, max_width=None):
    """Per-frame mean red of forehead ROI + face-centre motion proxy.

    Optional (used by evaluate_mcd.py, defaults keep the UBFC behaviour):
      start_s / max_seconds  analyse only that part of a long video
      max_width              downscale wider frames first (the browser app works on
                             640x480, and it makes full-HD videos ~10x faster)
    Timestamps t are absolute video time, so they line up with ground-truth files."""
    cap = cv2.VideoCapture(video_path)
    video_fps = cap.get(cv2.CAP_PROP_FPS) or FPS
    red, motion, t = [], [], []
    prev = None
    idx = int(round(start_s * video_fps))
    end_idx = idx + int(round(max_seconds * video_fps)) if max_seconds else None
    if idx:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
    while end_idx is None or idx < end_idx:
        ok, frame = cap.read()
        if not ok:
            break
        if max_width and frame.shape[1] > max_width:
            sc = max_width / frame.shape[1]
            frame = cv2.resize(frame, (max_width, int(round(frame.shape[0] * sc))),
                               interpolation=cv2.INTER_AREA)
        box = detector(frame)
        if box is None:
            red.append(np.nan); motion.append(np.nan); t.append(idx / video_fps)
            idx += 1
            continue
        x, y, bw, bh = box
        cx, cy = x + bw / 2, y + bh / 2
        m = 0.0 if prev is None else float(np.hypot(cx - prev[0], cy - prev[1]))
        prev = (cx, cy)
        fx, fy = x + bw * 0.25, y + bh * 0.05
        fw, fh = bw * 0.5, bh * 0.25
        x0, y0 = int(max(0, fx)), int(max(0, fy))
        x1 = int(min(frame.shape[1], fx + fw))
        y1 = int(min(frame.shape[0], fy + fh))
        roi = frame[y0:y1, x0:x1]
        red.append(float(roi[:, :, 2].mean()) if roi.size else np.nan)
        motion.append(m)
        t.append(idx / video_fps)
        idx += 1
    cap.release()
    return np.array(red), np.array(motion), np.array(t), video_fps


# ---- ground truth ----------------------------------------------------------------
def load_ground_truth(folder, dataset):
    """Return (gt_time_s, gt_hr_bpm). Handles both UBFC layouts defensively."""
    txt = os.path.join(folder, "ground_truth.txt")
    xmp = os.path.join(folder, "gtdump.xmp")
    if os.path.exists(txt):                       # DATASET_2: 3 rows
        rows = [np.array(l.split(), dtype=float) for l in open(txt) if l.strip()]
        if len(rows) >= 3:
            return rows[2], rows[1]               # time (s), HR (bpm)
    if os.path.exists(xmp):                       # DATASET_1: CSV, time in ms
        arr = np.genfromtxt(xmp, delimiter=",")
        arr = arr[~np.isnan(arr).any(axis=1)]
        return arr[:, 0] / 1000.0, arr[:, 1]      # col0 = ms, col1 = HR
    raise FileNotFoundError(f"No ground truth found in {folder}")


# ---- per-subject evaluation ---------------------------------------------------------
def get_signal(folder, detector, cache_dir=None):
    """Extract (or load cached) forehead-red signal so sweeps don't re-run face detection."""
    name = os.path.basename(folder)
    cp = os.path.join(cache_dir, f"{name}.npz") if cache_dir else None
    if cp and os.path.exists(cp):
        z = np.load(cp)
        return z["red"], z["motion"], z["t"], float(z["fps"])
    red, motion, t, vfps = extract_signal(os.path.join(folder, "vid.avi"), detector)
    if cp:
        os.makedirs(cache_dir, exist_ok=True)
        np.savez(cp, red=red, motion=motion, t=t, fps=vfps)
    return red, motion, t, vfps


def evaluate_subject(folder, dataset, detector, motion_thresh, cache_dir=None, params=None):
    red, motion, t, vfps = get_signal(folder, detector, cache_dir)
    gt_t, gt_hr = load_ground_truth(folder, dataset)
    params = params or {}

    face_rate = float(np.mean(~np.isnan(red)))
    # forward-fill missing frames so the window length stays 150 samples
    s = pd.Series(red).ffill().bfill().to_numpy()
    mo = pd.Series(motion).fillna(0).to_numpy()

    rows = []
    step = int(round(STEP_SECONDS * vfps))
    for end in range(max(MIN_SAMPLES, step), len(s) + 1, step):
        win = s[max(0, end - WINDOW):end]
        bpm = calculate_heart_rate(win, fps=vfps, **params)  # fps = measured/stream rate
        t_end = t[end - 1]
        # reference HR = mean of oximeter HR over the same window
        m = (gt_t >= t[max(0, end - WINDOW)]) & (gt_t <= t_end)
        ref = float(np.nanmean(gt_hr[m])) if m.any() else np.nan
        rows.append(dict(subject=os.path.basename(folder), t=t_end, est_bpm=bpm,
                         ref_bpm=ref, motion=float(mo[max(0, end - WINDOW):end].mean()),
                         detected=bpm > 0))
    df = pd.DataFrame(rows)
    df["abs_err"] = (df.est_bpm - df.ref_bpm).abs().where(df.detected)
    df["high_motion"] = df.motion > motion_thresh
    df.attrs["face_rate"] = face_rate
    return df


def summarize(df):
    v = df[df.detected]
    err = (v.est_bpm - v.ref_bpm).dropna()
    out = dict(n_windows=len(df), n_detected=int(df.detected.sum()),
               detection_rate=float(df.detected.mean()))
    if len(err):
        n = len(err)
        sd = err.std(ddof=1) if n > 1 else np.nan
        out.update(MAE=err.abs().mean(), RMSE=float(np.sqrt((err ** 2).mean())),
                   bias=err.mean(), SD_err=sd,
                   LoA_low=err.mean() - 1.96 * sd, LoA_high=err.mean() + 1.96 * sd,
                   pearson_r=float(np.corrcoef(v.est_bpm[err.index], v.ref_bpm[err.index])[0, 1]) if n > 2 else np.nan,
                   within_5bpm=float((err.abs() <= 5).mean()),
                   within_10bpm=float((err.abs() <= 10).mean()))
    # alert-level behaviour vs. reference (ref is oximeter HR)
    ref_alert = (df.ref_bpm >= EMERGENCY_THRESHOLD) | (df.ref_bpm < LOW_BPM_THRESHOLD)
    est_alert = df.est_bpm.apply(alert_decision)
    out.update(false_alert_windows=int((est_alert & ~ref_alert).sum()),
               missed_alert_windows=int((~est_alert & ref_alert).sum()),
               ref_alert_windows=int(ref_alert.sum()))
    return out


def bootstrap_ci(x, n=5000, seed=0):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if len(x) < 2:
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    means = [rng.choice(x, len(x)).mean() for _ in range(n)]
    return tuple(np.percentile(means, [2.5, 97.5]))


def run_sweep(folders, args, detector, cache):
    """Sensitivity of MAE / detection rate to the empirically chosen constants."""
    import itertools
    grid = [("legacy_5_15samples", LEGACY)]
    for thr, gap, sm in itertools.product([0.1, 0.2, 0.3, 0.4, 0.5],
                                          [0.25, 0.33, 0.40, 0.50],
                                          [0.07, 0.10, 0.13, 0.17]):
        grid.append((f"thr{thr}_gap{gap}_sm{sm}",
                     dict(thr_frac=thr, gap_s=gap, smooth_s=sm)))
    rows = []
    for label, prm in grid:
        parts = [evaluate_subject(f, args.dataset, detector, np.inf, cache, prm) for f in folders]
        d = pd.concat(parts, ignore_index=True)
        per = d.groupby("subject").abs_err.mean()
        rows.append(dict(config=label, **{k: v for k, v in prm.items()},
                         MAE=d.abs_err.mean(), subject_MAE_SD=per.std(ddof=1),
                         detection_rate=d.detected.mean()))
        print(f"{label:28s} MAE={rows[-1]['MAE']:.2f} det={rows[-1]['detection_rate']:.0%}")
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(args.out, "sweep_results.csv"), index=False)
    print(f"\nsweep written to {args.out}/sweep_results.csv")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=int, default=2, choices=[1, 2])
    ap.add_argument("--root", default=None,
                    help="folder containing subject folders "
                         "(default: <project>/data/UBFC-rPPG/DATASET_<dataset>)")
    ap.add_argument("--out", default=None,
                    help="output folder (default: <project>/results/dataset<dataset>)")
    ap.add_argument("--motion-thresh", type=float, default=None,
                    help="face-centre px/frame; default = median over all windows")
    ap.add_argument("--legacy-params", action="store_true",
                    help="use the original fixed 5-sample smoothing / 15-sample gap")
    ap.add_argument("--sweep", action="store_true",
                    help="parameter sensitivity analysis (threshold, gap, smoothing)")
    args = ap.parse_args()

    project = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if args.root is None:
        args.root = os.path.join(project, "data", "UBFC-rPPG", f"DATASET_{args.dataset}")
    if args.out is None:
        args.out = os.path.join(project, "results", f"dataset{args.dataset}")

    folders = sorted(d for d in glob.glob(os.path.join(args.root, "subject*"))
                     if os.path.exists(os.path.join(d, "vid.avi")))
    if not folders:
        sys.exit(f"No subject*/vid.avi found under {args.root}\n"
                 "Download UBFC-rPPG and copy it there - see data/README.md for the exact layout.")
    os.makedirs(args.out, exist_ok=True)

    detector = FaceBox()
    print(f"Face detector: {detector.name}; subjects: {len(folders)}")

    cache = os.path.join(args.out, "signal_cache")
    params = LEGACY if args.legacy_params else {}

    if args.sweep:
        run_sweep(folders, args, detector, cache)
        return

    parts = []
    for f in folders:
        try:
            d = evaluate_subject(f, args.dataset, detector, motion_thresh=np.inf,
                                 cache_dir=cache, params=params)
            parts.append(d)
            print(f"  {os.path.basename(f)}: face found in {d.attrs['face_rate']:.1%} frames, "
                  f"MAE={d.abs_err.mean():.2f} BPM, detected {d.detected.mean():.0%}")
        except Exception as e:
            print(f"  {os.path.basename(f)}: SKIPPED ({e})")
    allw = pd.concat(parts, ignore_index=True)

    thr = args.motion_thresh if args.motion_thresh is not None else float(allw.motion.median())
    allw["high_motion"] = allw.motion > thr
    allw.to_csv(os.path.join(args.out, "windows.csv"), index=False)

    per_subj = pd.DataFrame([dict(subject=s, **summarize(g)) for s, g in allw.groupby("subject")])
    per_subj.to_csv(os.path.join(args.out, "per_subject.csv"), index=False)

    overall = summarize(allw)
    lo, hi = bootstrap_ci(per_subj.MAE)
    overall["MAE_subject_mean"] = per_subj.MAE.mean()
    overall["MAE_subject_SD"] = per_subj.MAE.std(ddof=1)
    overall["MAE_subject_CI95_low"], overall["MAE_subject_CI95_high"] = lo, hi
    overall["motion_threshold_px_per_frame"] = thr
    for name, g in (("low_motion", allw[~allw.high_motion]), ("high_motion", allw[allw.high_motion])):
        for k, v in summarize(g).items():
            overall[f"{name}_{k}"] = v
    # Replay of the FULL cardiac alert logic (calibration baseline, dynamic band,
    # 3-consecutive-reading rule, absolute >=130) on each subject's estimates.
    # UBFC subjects are seated/at rest or playing a game, so an alert is counted as
    # "unjustified" unless the oximeter HR in that window was itself >= 130 BPM.
    # This measures false-alert behaviour of the trigger logic; it says nothing
    # about sensitivity to real emergencies (see synthetic_motion_experiment.py).
    replay_rows = []
    for d in parts:
        res = replay_alert_logic(list(d.est_bpm.fillna(0).to_numpy()))
        idx = res["alert_indices"]
        unjust = sum(1 for i in idx if not (d.ref_bpm.iloc[i] >= EMERGENCY_THRESHOLD))
        minutes = float(d.t.max()) / 60.0
        replay_rows.append(dict(subject=d.subject.iloc[0], baseline_bpm=res["baseline"],
                                n_alert_readings=len(idx), n_unjustified=unjust, minutes=minutes))
    replay = pd.DataFrame(replay_rows)
    replay.to_csv(os.path.join(args.out, "alert_replay.csv"), index=False)
    tot_min = replay.minutes.sum()
    overall["replay_subjects"] = len(replay)
    overall["replay_total_minutes"] = tot_min
    overall["replay_unjustified_alert_readings"] = int(replay.n_unjustified.sum())
    overall["replay_subjects_with_unjustified_alert"] = int((replay.n_unjustified > 0).sum())
    overall["replay_unjustified_per_hour"] = float(replay.n_unjustified.sum() / (tot_min / 60.0)) if tot_min else float("nan")

    pd.Series(overall).to_csv(os.path.join(args.out, "overall_summary.csv"), header=["value"])

    # Bland-Altman plot
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        v = allw[allw.detected].dropna(subset=["ref_bpm"])
        mean = (v.est_bpm + v.ref_bpm) / 2
        diff = v.est_bpm - v.ref_bpm
        plt.figure(figsize=(6, 4))
        plt.scatter(mean, diff, s=8, alpha=.5)
        plt.axhline(diff.mean(), color="k")
        for k in (-1.96, 1.96):
            plt.axhline(diff.mean() + k * diff.std(ddof=1), color="r", ls="--")
        plt.xlabel("Mean of rPPG and oximeter HR (BPM)")
        plt.ylabel("rPPG - oximeter (BPM)")
        plt.title("Bland-Altman, UBFC-rPPG")
        plt.tight_layout()
        plt.savefig(os.path.join(args.out, "bland_altman.png"), dpi=200)
    except Exception as e:
        print("plot skipped:", e)

    print("\n=== OVERALL ===")
    for k, v in overall.items():
        print(f"{k:38s} {v:.3f}" if isinstance(v, float) else f"{k:38s} {v}")
    print(f"\nResults written to {args.out}/")


if __name__ == "__main__":
    main()
