#!/usr/bin/env python3
"""
Download a SUBSET of the MCD-rPPG dataset (CC-BY-4.0) from Hugging Face: for N subjects,
the frontal-HD-webcam 'before' (rest) and 'after' (post-exercise) videos plus their
synchronised PPG files. The full dataset is far too large for this experiment.

    pip install huggingface_hub
    python validation/download_mcd_subset.py --dry-run          # shows size first
    python validation/download_mcd_subset.py --n 20 --seed 1    # downloads to data/MCD-rPPG/
    python validation/download_mcd_subset.py --ids 1020,1021

Then run:  python validation/evaluate_mcd.py

Dataset: https://huggingface.co/datasets/kyegorov/mcd_rppg  (license CC-BY-4.0; cite
Egorov et al., "Gaze into the Heart: A Multi-View Video Dataset for rPPG and Health
Biomarkers Estimation", ACM Multimedia 2025, doi 10.1145/3746027.3758255).
NOTE: written from the dataset's published folder layout and not run against the live
repository by the authors of this script - if a file name differs, the script will say so.
"""
import argparse
import os
import random
import re
import sys

REPO = "kyegorov/mcd_rppg"


def main():
    project = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--ids", default=None, help="comma-separated subject ids instead of random sampling")
    ap.add_argument("--camera", default="FullHDwebcam")
    ap.add_argument("--out", default=os.path.join(project, "data", "MCD-rPPG"))
    ap.add_argument("--dry-run", action="store_true", help="only list what would be downloaded and its size")
    a = ap.parse_args()

    try:
        from huggingface_hub import HfApi, hf_hub_download
    except ImportError:
        sys.exit("pip install huggingface_hub   (then re-run)")

    api = HfApi()
    files = set(api.list_repo_files(REPO, repo_type="dataset"))
    pat = re.compile(rf"^video/(?P<id>.+?)_{re.escape(a.camera)}_(?P<state>before|after)\.avi$")
    states = {}
    for f in files:
        m = pat.match(f)
        if m and f"ppg_sync/{f[6:-4]}.txt" in files:
            states.setdefault(m["id"], set()).add(m["state"])
    ids = sorted(i for i, s in states.items() if s == {"before", "after"})
    if not ids:
        sys.exit(f"No '{a.camera}' before/after video + ppg_sync pairs found in {REPO}. "
                 "Check the repository file list; the layout may have changed.")
    if a.ids:
        chosen = [i.strip() for i in a.ids.split(",")]
        missing = [i for i in chosen if i not in ids]
        if missing:
            sys.exit(f"ids not available with both states: {missing}")
    else:
        random.Random(a.seed).shuffle(ids)
        chosen = sorted(ids[:a.n])

    wanted = ["db.csv"] if "db.csv" in files else []
    for i in chosen:
        for st in ("before", "after"):
            stem = f"{i}_{a.camera}_{st}"
            wanted += [f"video/{stem}.avi", f"ppg_sync/{stem}.txt"]

    try:
        info = api.dataset_info(REPO, files_metadata=True)
        size = {s.rfilename: (s.size or 0) for s in info.siblings}
        total = sum(size.get(f, 0) for f in wanted)
        print(f"{len(chosen)} subjects, {len(wanted)} files, approx {total / 1e9:.1f} GB")
    except Exception:
        print(f"{len(chosen)} subjects, {len(wanted)} files (size unavailable)")
    if a.dry_run:
        print("subjects:", ", ".join(chosen))
        return
    for k, f in enumerate(wanted, 1):
        print(f"[{k}/{len(wanted)}] {f}")
        hf_hub_download(repo_id=REPO, repo_type="dataset", filename=f, local_dir=a.out)
    print(f"Done -> {a.out}\nNext: python validation/evaluate_mcd.py")


if __name__ == "__main__":
    main()
