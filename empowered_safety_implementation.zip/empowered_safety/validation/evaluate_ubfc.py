#!/usr/bin/env python3
"""
Offline validation of the Empowered Safety rPPG module on the public
UBFC-rPPG dataset (Bobbia et al., 2019, Pattern Recognition Letters).

*** The results in the paper come from:  --method pos --split test  (POS, 15 s windows, 3 s step) ***
    python evaluate_ubfc.py --root <DATASET_2> --split dev  --method pos --out results/dev_pos
    python evaluate_ubfc.py --root <DATASET_2> --split test --method pos --out results/test_pos
    python evaluate_ubfc.py --root <DATASET_2> --split test --method peak --out results/test_peak   # replaced red-channel baseline
    python evaluate_ubfc.py --root <DATASET_2> --split test --method pos --sweep                      # optional, post-hoc only
The POS path (pos_hr, evaluate_subject_pos) mirrors calculateHeartRate() in script.js:
central-face ROI (x 15-85 %, y 30-85 % of the BlazeFace box), per-channel mean normalisation,
POS projection, linear detrend, Hann window, spectrum zero-padded to 8n points, peak in 0.7-3.0 Hz.
Differences from the browser (see the paper): MediaPipe BlazeFace instead of the TF.js build; no resampling
to a 30 Hz grid (the video's own frame rate is used); small epsilon instead of an explicit zero check.
The "peak" method below is the REPLACED red-channel detector (baseline only). The text after this
paragraph is the original docstring of that baseline.

Why this exists
---------------
The browser app (script.js) estimates heart rate from the red channel of a
forehead ROI found with BlazeFace. Instead of collecting volunteer data
(which needs ethics approval), the same algorithm is run here on pre-recorded,
publicly released videos that come with pulse-oximeter ground truth.

Fidelity to script.js
---------------------
calculate_heart_rate() is a line-by-line port of calculateHeartRate():
  * mean removal, centred moving average (half-window 0.10 s, edge-truncated)
  * local-maximum test over +/-3 neighbours, threshold = 0.3 * max(smoothed)
  * refractory gap > 0.33 s, >= 3 peaks required
  * 10 %-trimmed mean of peak intervals, BPM = 60 / (interval / fps)
  * outputs outside [50, 150] BPM are rejected (returns 0)
Smoothing half-window and refractory gap are defined in seconds and converted
to samples with the frame rate (3 and 10 samples at 30 FPS). The earlier
fixed 5 / 15 samples capped detectable HR near 112 BPM; pass
--legacy-params (or see --sweep) to reproduce that behaviour.
Forehead ROI geometry (x+25 % w, y+5 % h, 50 % w, 25 % h of the face box)
and the rolling 150-frame window evaluated every 3 s also match script.js.

Face detection uses MediaPipe's short-range face detector, which is a BlazeFace
model (the same architecture as the TF.js BlazeFace used in the browser). The
box is not bit-identical to the TF.js output, so state this in the paper.

Expected dataset layout (UBFC-rPPG)
-----------------------------------
DATASET_1/subjectN/vid.avi  + gtdump.xmp
DATASET_2/subjectN/vid.avi  + ground_truth.txt
Pass the folder that contains the subject folders (e.g. .../DATASET_2).

Usage
-----
python evaluate_ubfc.py --root /path/to/DATASET_2 --out results_dataset2
python evaluate_ubfc.py --root /path/to/DATASET_1 --out results_dataset1 --dataset 1
"""
import argparse
import os
import sys
import glob
import numpy as np
import pandas as pd
import cv2

# ---- constants copied from script.js -------------------------------------
FPS = 30
MIN_BPM, MAX_BPM = 50, 150
WINDOW = 150            # redValues.slice(-150)
MIN_SAMPLES = 90        # calculateHeartRate returns 0 below this
STEP_SECONDS = 3        # readings every ~3 s
CALIBRATION_SECONDS = 30
EMERGENCY_THRESHOLD = 130
LOW_BPM_THRESHOLD = 60
DYNAMIC_UPPER_OFFSET = 40
DYNAMIC_LOWER_OFFSET = 20
SUSTAINED_READINGS = 3


# ---- algorithm port ---------------------------------------------------------
SMOOTH_HALF_WINDOW_S = 0.10
MIN_PEAK_GAP_S = 0.33
PEAK_THRESHOLD_FRAC = 0.3
LEGACY = dict(smooth_samples=5, gap_samples=15)   # original fixed-sample behaviour


def _js_round(x):
    return int(np.floor(x + 0.5))                 # JS Math.round semantics


def calculate_heart_rate(signal, fps=FPS, smooth_s=SMOOTH_HALF_WINDOW_S,
                         gap_s=MIN_PEAK_GAP_S, thr_frac=PEAK_THRESHOLD_FRAC,
                         smooth_samples=None, gap_samples=None):
    """Port of calculateHeartRate() in script.js. Returns BPM or 0.
    smooth_samples / gap_samples override the time-based values (legacy mode)."""
    signal = np.asarray(signal, dtype=float)
    if len(signal) < MIN_SAMPLES:
        return 0.0
    w = smooth_samples if smooth_samples is not None else max(1, _js_round(fps * smooth_s))
    gap = gap_samples if gap_samples is not None else max(2, _js_round(fps * gap_s))

    filtered = signal - signal.mean()
    n = len(filtered)
    smoothed = np.empty(n)
    for i in range(n):
        lo, hi = max(0, i - w), min(n - 1, i + w)
        smoothed[i] = filtered[lo:hi + 1].mean()

    threshold = smoothed.max() * thr_frac
    peaks = []
    for i in range(5, n - 5):
        v = smoothed[i]
        if (v > smoothed[i - 1] and v > smoothed[i - 2] and v > smoothed[i - 3]
                and v > smoothed[i + 1] and v > smoothed[i + 2] and v > smoothed[i + 3]
                and v > threshold):
            if not peaks or i - peaks[-1] > gap:
                peaks.append(i)

    if len(peaks) < 3:
        return 0.0
    intervals = sorted(peaks[i] - peaks[i - 1] for i in range(1, len(peaks)))
    t0 = int(np.floor(len(intervals) * 0.1))
    t1 = int(np.ceil(len(intervals) * 0.9))
    trimmed = intervals[t0:t1]
    if not trimmed:
        return 0.0
    bpm = 60.0 / (float(np.mean(trimmed)) / fps)
    return bpm if MIN_BPM <= bpm <= MAX_BPM else 0.0


# ---- face / ROI ----------------------------------------------------------------
class FaceBox:
    """BlazeFace short-range face detector via MediaPipe.

    Uses the legacy `mp.solutions` API when present, otherwise the MediaPipe Tasks API
    (same BlazeFace short-range model, downloaded once next to this script).
    There is deliberately NO silent fallback to another detector: results must come
    from BlazeFace to match the paper.
    """
    MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/face_detector/"
                 "blaze_face_short_range/float16/1/blaze_face_short_range.tflite")

    def __init__(self):
        import mediapipe as mp
        self.mp_mod = mp
        self.legacy = None
        self.tasks = None
        if hasattr(mp, "solutions") and hasattr(mp.solutions, "face_detection"):
            self.legacy = mp.solutions.face_detection.FaceDetection(
                model_selection=0, min_detection_confidence=0.5)
            self.name = "mediapipe-blazeface (legacy solutions API)"
        else:
            import urllib.request
            from mediapipe.tasks import python as mp_python
            from mediapipe.tasks.python import vision
            model = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "blaze_face_short_range.tflite")
            if not os.path.exists(model):
                print("Downloading BlazeFace short-range model ...")
                urllib.request.urlretrieve(self.MODEL_URL, model)
            opts = vision.FaceDetectorOptions(
                base_options=mp_python.BaseOptions(model_asset_path=model),
                running_mode=vision.RunningMode.IMAGE,
                min_detection_confidence=0.5)
            self.tasks = vision.FaceDetector.create_from_options(opts)
            self.name = "mediapipe-blazeface (Tasks API, short-range model)"

    def __call__(self, bgr):
        h, w = bgr.shape[:2]
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        if self.legacy is not None:
            res = self.legacy.process(rgb)
            if not res.detections:
                return None
            b = res.detections[0].location_data.relative_bounding_box
            return b.xmin * w, b.ymin * h, b.width * w, b.height * h
        img = self.mp_mod.Image(image_format=self.mp_mod.ImageFormat.SRGB,
                                data=np.ascontiguousarray(rgb))
        res = self.tasks.detect(img)
        if not res.detections:
            return None
        bb = res.detections[0].bounding_box
        return float(bb.origin_x), float(bb.origin_y), float(bb.width), float(bb.height)


def extract_signal(video_path, detector):
    """Per-frame mean red of forehead ROI + face-centre motion proxy."""
    cap = cv2.VideoCapture(video_path)
    video_fps = cap.get(cv2.CAP_PROP_FPS) or FPS
    red, motion, t = [], [], []
    prev = None
    idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        box = detector(frame)
        if box is None:
            red.append(np.nan); motion.append(np.nan); t.append(idx / video_fps)
            idx += 1
            continue
        x, y, bw, bh = box
        cx, cy = x + bw / 2, y + bh / 2
        m = 0.0 if prev is None else float(np.hypot(cx - prev[0], cy - prev[1]))
        prev = (cx, cy)
        fx, fy = x + bw * 0.25, y + bh * 0.05
        fw, fh = bw * 0.5, bh * 0.25
        x0, y0 = int(max(0, fx)), int(max(0, fy))
        x1 = int(min(frame.shape[1], fx + fw))
        y1 = int(min(frame.shape[0], fy + fh))
        roi = frame[y0:y1, x0:x1]
        red.append(float(roi[:, :, 2].mean()) if roi.size else np.nan)
        motion.append(m)
        t.append(idx / video_fps)
        idx += 1
    cap.release()
    return np.array(red), np.array(motion), np.array(t), video_fps


# ---- ground truth ----------------------------------------------------------------
def _clean_hr(hr):
    """Oximeter dropouts appear as implausible values (e.g. 0 or 1 BPM); mark them missing
    so they do not corrupt the reference. Valid range 40-220 BPM."""
    hr = np.asarray(hr, dtype=float).copy()
    hr[(hr < 40) | (hr > 220)] = np.nan
    return hr


def load_ground_truth(folder, dataset):
    """Return (gt_time_s, gt_hr_bpm). Handles both UBFC layouts defensively."""
    txt = os.path.join(folder, "ground_truth.txt")
    xmp = os.path.join(folder, "gtdump.xmp")
    if os.path.exists(txt):                       # DATASET_2: 3 rows
        rows = [np.array(l.split(), dtype=float) for l in open(txt) if l.strip()]
        if len(rows) >= 3:
            return rows[2], _clean_hr(rows[1])    # time (s), HR (bpm)
    if os.path.exists(xmp):                       # DATASET_1: CSV, time in ms
        arr = np.genfromtxt(xmp, delimiter=",")
        arr = arr[~np.isnan(arr).any(axis=1)]
        return arr[:, 0] / 1000.0, _clean_hr(arr[:, 1])  # col0 = ms, col1 = HR
    raise FileNotFoundError(f"No ground truth found in {folder}")


# ---- per-subject evaluation ---------------------------------------------------------
def get_signal(folder, detector, cache_dir=None):
    """Extract (or load cached) forehead-red signal so sweeps don't re-run face detection."""
    name = os.path.basename(folder)
    cp = os.path.join(cache_dir, f"{name}.npz") if cache_dir else None
    if cp and os.path.exists(cp):
        z = np.load(cp)
        return z["red"], z["motion"], z["t"], float(z["fps"])
    red, motion, t, vfps = extract_signal(os.path.join(folder, "vid.avi"), detector)
    if cp:
        os.makedirs(cache_dir, exist_ok=True)
        np.savez(cp, red=red, motion=motion, t=t, fps=vfps)
    return red, motion, t, vfps


def evaluate_subject(folder, dataset, detector, motion_thresh, cache_dir=None, params=None):
    red, motion, t, vfps = get_signal(folder, detector, cache_dir)
    gt_t, gt_hr = load_ground_truth(folder, dataset)
    params = params or {}

    face_rate = float(np.mean(~np.isnan(red)))
    # forward-fill missing frames so the window length stays 150 samples
    s = pd.Series(red).ffill().bfill().to_numpy()
    mo = pd.Series(motion).fillna(0).to_numpy()

    rows = []
    step = int(round(STEP_SECONDS * vfps))
    for end in range(max(MIN_SAMPLES, step), len(s) + 1, step):
        win = s[max(0, end - WINDOW):end]
        bpm = calculate_heart_rate(win, fps=vfps, **params)  # fps = measured/stream rate
        t_end = t[end - 1]
        # reference HR = mean of oximeter HR over the same window
        m = (gt_t >= t[max(0, end - WINDOW)]) & (gt_t <= t_end)
        ref = float(np.nanmean(gt_hr[m])) if m.any() else np.nan
        rows.append(dict(subject=os.path.basename(folder), t=t_end, est_bpm=bpm,
                         ref_bpm=ref, motion=float(mo[max(0, end - WINDOW):end].mean()),
                         detected=bpm > 0))
    df = pd.DataFrame(rows)
    df["abs_err"] = (df.est_bpm - df.ref_bpm).abs().where(df.detected)
    df["high_motion"] = df.motion > motion_thresh
    df.attrs["face_rate"] = face_rate
    return df



# ---- POS (chrominance) method, evaluated as an alternative to the red-channel peak method ----
POS_WINDOW_S = 15.0
POS_BAND_HZ = (0.7, 3.0)
FORCED_DEV = ["subject1", "subject10", "subject11"]   # already inspected while debugging -> dev set


def extract_rgb_signal(video_path, detector):
    """Per-frame mean R,G,B of a central-face ROI + face-centre motion proxy."""
    cap = cv2.VideoCapture(video_path)
    video_fps = cap.get(cv2.CAP_PROP_FPS) or FPS
    rgb, motion, t = [], [], []
    prev, idx = None, 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        t.append(idx / video_fps); idx += 1
        box = detector(frame)
        if box is None:
            rgb.append([np.nan] * 3); motion.append(np.nan); continue
        x, y, bw, bh = box
        cx, cy = x + bw / 2, y + bh / 2
        motion.append(0.0 if prev is None else float(np.hypot(cx - prev[0], cy - prev[1])))
        prev = (cx, cy)
        H, W = frame.shape[:2]
        x0, y0 = int(max(0, x + 0.15 * bw)), int(max(0, y + 0.30 * bh))
        x1, y1 = int(min(W, x + 0.85 * bw)), int(min(H, y + 0.85 * bh))
        roi = frame[y0:y1, x0:x1]
        rgb.append([roi[:, :, 2].mean(), roi[:, :, 1].mean(), roi[:, :, 0].mean()]
                   if roi.size else [np.nan] * 3)
    cap.release()
    return np.array(rgb), np.array(motion), np.array(t), video_fps


def get_rgb_signal(folder, detector, cache_dir=None):
    name = os.path.basename(folder)
    cp = os.path.join(cache_dir, f"{name}_rgb.npz") if cache_dir else None
    if cp and os.path.exists(cp):
        z = np.load(cp)
        return z["rgb"], z["motion"], z["t"], float(z["fps"])
    rgb, motion, t, vfps = extract_rgb_signal(os.path.join(folder, "vid.avi"), detector)
    if cp:
        os.makedirs(cache_dir, exist_ok=True)
        np.savez(cp, rgb=rgb, motion=motion, t=t, fps=vfps)
    return rgb, motion, t, vfps


def pos_hr(rgb, fps, band=POS_BAND_HZ):
    """POS projection (Wang et al., 2017) over one window, then spectral peak in `band`."""
    rgb = np.asarray(rgb, float)
    if len(rgb) < 3 * fps or np.any(rgb.mean(axis=0) <= 0):
        return 0.0
    n = rgb / rgb.mean(axis=0)
    s1 = n[:, 1] - n[:, 2]
    s2 = n[:, 1] + n[:, 2] - 2 * n[:, 0]
    h = s1 + (s1.std() / (s2.std() + 1e-9)) * s2
    k = np.arange(len(h))
    h = h - np.polyval(np.polyfit(k, h, 1), k)          # remove linear trend
    spec = np.abs(np.fft.rfft(h * np.hanning(len(h)), n=len(h) * 8))
    f = np.fft.rfftfreq(len(h) * 8, 1.0 / fps)
    m = (f >= band[0]) & (f <= band[1])
    return float(60.0 * f[m][np.argmax(spec[m])]) if m.any() else 0.0


def evaluate_subject_pos(folder, dataset, detector, cache_dir=None, window_s=POS_WINDOW_S):
    rgb, motion, t, vfps = get_rgb_signal(folder, detector, cache_dir)
    gt_t, gt_hr = load_ground_truth(folder, dataset)
    face_rate = float(np.mean(~np.isnan(rgb[:, 0])))
    s = pd.DataFrame(rgb).ffill().bfill().to_numpy()
    mo = pd.Series(motion).fillna(0).to_numpy()
    W, step = int(round(window_s * vfps)), int(round(STEP_SECONDS * vfps))
    rows = []
    for end in range(W, len(s) + 1, step):
        bpm = pos_hr(s[end - W:end], vfps)
        m = (gt_t >= t[end - W]) & (gt_t <= t[end - 1])
        ref = float(np.nanmean(gt_hr[m])) if m.any() and not np.all(np.isnan(gt_hr[m])) else np.nan
        rows.append(dict(subject=os.path.basename(folder), t=t[end - 1], est_bpm=bpm, ref_bpm=ref,
                         motion=float(mo[end - W:end].mean()), detected=bpm > 0))
    df = pd.DataFrame(rows)
    df["abs_err"] = (df.est_bpm - df.ref_bpm).abs().where(df.detected)
    df["high_motion"] = False
    df.attrs["face_rate"] = face_rate
    return df


def select_split(folders, which):
    """Reproducible dev/test split. Dev = FORCED_DEV (already inspected) + random others, 10 total."""
    import random, json
    if which == "all":
        return folders, None
    names = [os.path.basename(f) for f in folders]
    forced = [n for n in FORCED_DEV if n in names]
    rest = sorted(n for n in names if n not in forced)
    k = max(0, min(len(rest), 10 - len(forced)))
    dev = set(forced) | set(random.Random(0).sample(rest, k))
    chosen = [f for f in folders if (os.path.basename(f) in dev) == (which == "dev")]
    return chosen, dict(dev=sorted(dev), test=sorted(n for n in names if n not in dev))


def alert_decision(est):
    """Absolute-threshold part of handleMonitoringReading()."""
    return est >= EMERGENCY_THRESHOLD or (0 < est < LOW_BPM_THRESHOLD)


def summarize(df):
    v = df[df.detected]
    err = (v.est_bpm - v.ref_bpm).dropna()
    out = dict(n_windows=len(df), n_detected=int(df.detected.sum()),
               detection_rate=float(df.detected.mean()))
    if len(err):
        n = len(err)
        sd = err.std(ddof=1) if n > 1 else np.nan
        out.update(MAE=err.abs().mean(), RMSE=float(np.sqrt((err ** 2).mean())),
                   bias=err.mean(), SD_err=sd,
                   LoA_low=err.mean() - 1.96 * sd, LoA_high=err.mean() + 1.96 * sd,
                   pearson_r=float(np.corrcoef(v.est_bpm[err.index], v.ref_bpm[err.index])[0, 1]) if n > 2 else np.nan,
                   within_5bpm=float((err.abs() <= 5).mean()),
                   within_10bpm=float((err.abs() <= 10).mean()))
    # alert-level behaviour vs. reference (ref is oximeter HR)
    ref_alert = (df.ref_bpm >= EMERGENCY_THRESHOLD) | (df.ref_bpm < LOW_BPM_THRESHOLD)
    est_alert = df.est_bpm.apply(alert_decision)
    out.update(false_alert_windows=int((est_alert & ~ref_alert).sum()),
               missed_alert_windows=int((~est_alert & ref_alert).sum()),
               ref_alert_windows=int(ref_alert.sum()))
    return out


def bootstrap_ci(x, n=5000, seed=0):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if len(x) < 2:
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    means = [rng.choice(x, len(x)).mean() for _ in range(n)]
    return tuple(np.percentile(means, [2.5, 97.5]))


def run_sweep(folders, args, detector, cache):
    """Sensitivity of MAE / detection rate to the empirically chosen constants."""
    import itertools
    grid = [("legacy_5_15samples", LEGACY)]
    for thr, gap, sm in itertools.product([0.1, 0.2, 0.3, 0.4, 0.5],
                                          [0.25, 0.33, 0.40, 0.50],
                                          [0.07, 0.10, 0.13, 0.17]):
        grid.append((f"thr{thr}_gap{gap}_sm{sm}",
                     dict(thr_frac=thr, gap_s=gap, smooth_s=sm)))
    rows = []
    for label, prm in grid:
        parts = [evaluate_subject(f, args.dataset, detector, np.inf, cache, prm) for f in folders]
        d = pd.concat(parts, ignore_index=True)
        per = d.groupby("subject").abs_err.mean()
        rows.append(dict(config=label, **{k: v for k, v in prm.items()},
                         MAE=d.abs_err.mean(), subject_MAE_SD=per.std(ddof=1),
                         detection_rate=d.detected.mean()))
        print(f"{label:28s} MAE={rows[-1]['MAE']:.2f} det={rows[-1]['detection_rate']:.0%}")
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(args.out, "sweep_results.csv"), index=False)
    print(f"\nsweep written to {args.out}/sweep_results.csv")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="folder containing subject folders")
    ap.add_argument("--out", default="ubfc_results")
    ap.add_argument("--dataset", type=int, default=2, choices=[1, 2])
    ap.add_argument("--motion-thresh", type=float, default=None,
                    help="face-centre px/frame; default = median over all windows")
    ap.add_argument("--legacy-params", action="store_true",
                    help="use the original fixed 5-sample smoothing / 15-sample gap")
    ap.add_argument("--sweep", action="store_true",
                    help="parameter sensitivity analysis (threshold, gap, smoothing)")
    ap.add_argument("--method", choices=["peak", "pos"], default="peak",
                    help="peak = app's red-channel peak detector; pos = POS chrominance + FFT")
    ap.add_argument("--window-s", type=float, default=None,
                    help="window length in s for --method pos (default 15)")
    ap.add_argument("--split", choices=["all", "dev", "test"], default="all",
                    help="dev = 10 subjects used for method development; test = the remaining ones")
    args = ap.parse_args()

    folders = sorted(d for d in glob.glob(os.path.join(args.root, "subject*"))
                     if os.path.exists(os.path.join(d, "vid.avi")))
    if not folders:
        sys.exit(f"No subject*/vid.avi found under {args.root}")
    os.makedirs(args.out, exist_ok=True)
    folders, split_info = select_split(folders, args.split)
    if split_info:
        import json
        json.dump(split_info, open(os.path.join(args.out, "split.json"), "w"), indent=1)

    detector = FaceBox()
    print(f"Face detector: {detector.name}; subjects: {len(folders)}")

    cache = os.path.join(args.out, "signal_cache")
    params = LEGACY if args.legacy_params else {}

    if args.sweep and args.method == "pos":
        rows = []
        for w in (10.0, 15.0, 20.0):
            d = pd.concat([evaluate_subject_pos(f, args.dataset, detector, cache, w) for f in folders],
                          ignore_index=True)
            per = d.groupby("subject").abs_err.mean()
            rows.append(dict(window_s=w, MAE=d.abs_err.mean(), subject_MAE_SD=per.std(ddof=1),
                             detection_rate=d.detected.mean()))
            print(f"POS window {w:4.0f} s  MAE={rows[-1]['MAE']:.2f}  det={rows[-1]['detection_rate']:.0%}")
        pd.DataFrame(rows).to_csv(os.path.join(args.out, "sweep_results.csv"), index=False)
        return
    if args.sweep:
        run_sweep(folders, args, detector, cache)
        return

    parts = []
    for f in folders:
        try:
            if args.method == "pos":
                d = evaluate_subject_pos(f, args.dataset, detector, cache,
                                         args.window_s or POS_WINDOW_S)
            else:
                d = evaluate_subject(f, args.dataset, detector, motion_thresh=np.inf,
                                     cache_dir=cache, params=params)
            parts.append(d)
            print(f"  {os.path.basename(f)}: face found in {d.attrs['face_rate']:.1%} frames, "
                  f"MAE={d.abs_err.mean():.2f} BPM, detected {d.detected.mean():.0%}")
        except Exception as e:
            print(f"  {os.path.basename(f)}: SKIPPED ({e})")
    allw = pd.concat(parts, ignore_index=True)

    thr = args.motion_thresh if args.motion_thresh is not None else float(allw.motion.median())
    allw["high_motion"] = allw.motion > thr
    allw.to_csv(os.path.join(args.out, "windows.csv"), index=False)

    per_subj = pd.DataFrame([dict(subject=s, **summarize(g)) for s, g in allw.groupby("subject")])
    per_subj.to_csv(os.path.join(args.out, "per_subject.csv"), index=False)

    overall = summarize(allw)
    lo, hi = bootstrap_ci(per_subj.MAE)
    overall["MAE_subject_mean"] = per_subj.MAE.mean()
    overall["MAE_subject_SD"] = per_subj.MAE.std(ddof=1)
    overall["MAE_subject_CI95_low"], overall["MAE_subject_CI95_high"] = lo, hi
    overall["motion_threshold_px_per_frame"] = thr
    for name, g in (("low_motion", allw[~allw.high_motion]), ("high_motion", allw[allw.high_motion])):
        for k, v in summarize(g).items():
            overall[f"{name}_{k}"] = v
    pd.Series(overall).to_csv(os.path.join(args.out, "overall_summary.csv"), header=["value"])

    # Bland-Altman plot
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        v = allw[allw.detected].dropna(subset=["ref_bpm"])
        mean = (v.est_bpm + v.ref_bpm) / 2
        diff = v.est_bpm - v.ref_bpm
        plt.figure(figsize=(6, 4))
        plt.scatter(mean, diff, s=8, alpha=.5)
        plt.axhline(diff.mean(), color="k")
        for k in (-1.96, 1.96):
            plt.axhline(diff.mean() + k * diff.std(ddof=1), color="r", ls="--")
        plt.xlabel("Mean of rPPG and oximeter HR (BPM)")
        plt.ylabel("rPPG - oximeter (BPM)")
        plt.title("Bland-Altman, UBFC-rPPG")
        plt.tight_layout()
        plt.savefig(os.path.join(args.out, "bland_altman.png"), dpi=200)
    except Exception as e:
        print("plot skipped:", e)

    print("\n=== OVERALL ===")
    for k, v in overall.items():
        print(f"{k:38s} {v:.3f}" if isinstance(v, float) else f"{k:38s} {v}")
    print(f"\nResults written to {args.out}/")


if __name__ == "__main__":
    main()
