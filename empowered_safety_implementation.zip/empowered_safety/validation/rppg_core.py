"""
Pure-numpy port of the browser heart-rate pipeline in script.js.
No OpenCV / MediaPipe dependency, so it can be imported by the offline
evaluation scripts and the JS<->Python cross-check.

THE SHIPPED ESTIMATOR IS POS: calculate_heart_rate_pos() below mirrors
calculateHeartRate() in script.js (tests/crosscheck_js_python.py checks it).

calculate_heart_rate() (red-channel peak detection) is the LEGACY method that
the app used before POS. It is kept only for baseline comparisons (the
"peak" baseline in the paper) and for the older synthetic / MCD tools. The app
no longer runs it, so it is NOT covered by the JS cross-check.
"""
import numpy as np

# ---- constants copied from script.js -------------------------------------
FPS = 30
MIN_BPM, MAX_BPM = 50, 150
WINDOW = 150            # redValues.slice(-150)
MIN_SAMPLES = 90        # calculateHeartRate returns 0 below this
STEP_SECONDS = 3        # one reading per READING_INTERVAL_MS
CALIBRATION_SECONDS = 30
EMERGENCY_THRESHOLD = 130
LOW_BPM_THRESHOLD = 60
DYNAMIC_UPPER_OFFSET = 40
DYNAMIC_LOWER_OFFSET = 20
SUSTAINED_READINGS = 3

SMOOTH_HALF_WINDOW_S = 0.10
MIN_PEAK_GAP_S = 0.33
PEAK_THRESHOLD_FRAC = 0.3
LEGACY = dict(smooth_samples=5, gap_samples=15)   # original fixed-sample behaviour


# ---- POS constants copied from script.js ----------------------------------
POS_WINDOW_S = 15.0
POS_MIN_SPAN_S = 14.25
POS_RESAMPLE_HZ = 30
POS_FREQ_LO_HZ, POS_FREQ_HI_HZ = 0.7, 3.0
POS_ZERO_PAD = 8
ROI_X = (0.15, 0.85)    # central-face ROI, fractions of the face-box width
ROI_Y = (0.30, 0.85)    # ... and height
POS_MIN_BPM, POS_MAX_BPM = 60 * POS_FREQ_LO_HZ, 60 * POS_FREQ_HI_HZ   # 42, 180


def calculate_heart_rate_pos(r, g, b, t_ms):
    """POS heart rate from per-frame mean R, G, B and frame timestamps (ms).
    Mirrors calculateHeartRate() in script.js. Returns BPM, or 0.0 if the
    window is shorter than POS_MIN_SPAN_S or numerically unusable.
    There is no quality check: any usable window returns its strongest
    spectral peak in 0.7-3.0 Hz."""
    r, g, b, t = (np.asarray(x, dtype=float) for x in (r, g, b, t_ms))
    if len(t) < 2:
        return 0.0
    span_s = (t[-1] - t[0]) / 1000.0
    if not span_s >= POS_MIN_SPAN_S:
        return 0.0
    fs = POS_RESAMPLE_HZ
    n = int(np.floor(span_s * fs)) + 1
    grid = t[0] + np.arange(n) * (1000.0 / fs)
    R, G, B = (np.interp(grid, t, c) for c in (r, g, b))
    mR, mG, mB = R.mean(), G.mean(), B.mean()
    if not (mR > 0 and mG > 0 and mB > 0):
        return 0.0
    Rn, Gn, Bn = R / mR, G / mG, B / mB
    s1 = Gn - Bn
    s2 = Gn + Bn - 2 * Rn
    sd2 = s2.std()                      # population std, as in script.js
    if not sd2 > 0:
        return 0.0
    h = s1 + (s1.std() / sd2) * s2
    idx = np.arange(n)
    slope, intercept = np.polyfit(idx, h, 1)          # linear detrend
    h = h - (intercept + slope * idx)
    h = h * (0.5 - 0.5 * np.cos(2 * np.pi * idx / (n - 1)))   # Hann
    nfft = POS_ZERO_PAD * n
    spec = np.abs(np.fft.rfft(h, n=nfft)) ** 2
    df = fs / nfft
    k_lo, k_hi = int(np.ceil(POS_FREQ_LO_HZ / df)), int(np.floor(POS_FREQ_HI_HZ / df))
    k = k_lo + int(np.argmax(spec[k_lo:k_hi + 1]))
    return 60.0 * k * df


def _js_round(x):
    return int(np.floor(x + 0.5))                 # JS Math.round semantics


def calculate_heart_rate(signal, fps=FPS, smooth_s=SMOOTH_HALF_WINDOW_S,
                         gap_s=MIN_PEAK_GAP_S, thr_frac=PEAK_THRESHOLD_FRAC,
                         smooth_samples=None, gap_samples=None):
    """Port of calculateHeartRate() in script.js. Returns BPM or 0.
    smooth_samples / gap_samples override the time-based values (legacy mode)."""
    signal = np.asarray(signal, dtype=float)
    if len(signal) < MIN_SAMPLES:
        return 0.0
    w = smooth_samples if smooth_samples is not None else max(1, _js_round(fps * smooth_s))
    gap = gap_samples if gap_samples is not None else max(2, _js_round(fps * gap_s))

    filtered = signal - signal.mean()
    n = len(filtered)
    smoothed = np.empty(n)
    for i in range(n):
        lo, hi = max(0, i - w), min(n - 1, i + w)
        smoothed[i] = filtered[lo:hi + 1].mean()

    threshold = smoothed.max() * thr_frac
    peaks = []
    for i in range(5, n - 5):
        v = smoothed[i]
        if (v > smoothed[i - 1] and v > smoothed[i - 2] and v > smoothed[i - 3]
                and v > smoothed[i + 1] and v > smoothed[i + 2] and v > smoothed[i + 3]
                and v > threshold):
            if not peaks or i - peaks[-1] > gap:
                peaks.append(i)

    if len(peaks) < 3:
        return 0.0
    intervals = sorted(peaks[i] - peaks[i - 1] for i in range(1, len(peaks)))
    t0 = int(np.floor(len(intervals) * 0.1))
    t1 = int(np.ceil(len(intervals) * 0.9))
    trimmed = intervals[t0:t1]
    if not trimmed:
        return 0.0
    bpm = 60.0 / (float(np.mean(trimmed)) / fps)
    return bpm if MIN_BPM <= bpm <= MAX_BPM else 0.0


def alert_decision(est):
    """Absolute-threshold part of handleMonitoringReading()."""
    return est >= EMERGENCY_THRESHOLD or (0 < est < LOW_BPM_THRESHOLD)


def replay_alert_logic(readings):
    """Replay the FULL cardiac alert logic of script.js on a sequence of BPM
    readings (one per 3 s, 0 = failed estimate), starting at t=0 of the session.

    Mirrors finishCalibration() + handleMonitoringReading():
      * first CALIBRATION_SECONDS/STEP readings -> baseline (mean of valid ones)
      * dynamic band = [max(MIN_BPM, base-20), base+40]
      * alert if bpm >= 130 (absolute), or 3 consecutive out-of-band readings
      * bpm < 60 only shows a warning in the app (NOT an SOS), so it is not an alert here
    Returns dict(alert_indices=[reading index,...], baseline=float|None).
    The 60 s cooldown / confirmation dialog are not modelled (they only
    suppress repeats / delay dispatch; they do not change *whether* an alert fires).
    """
    n_cal = int(CALIBRATION_SECONDS / STEP_SECONDS)
    cal = [r for r in readings[:n_cal] if MIN_BPM <= r <= MAX_BPM]
    baseline = round(float(np.mean(cal))) if cal else None
    upper = lower = None
    if baseline is not None:
        upper = baseline + DYNAMIC_UPPER_OFFSET
        lower = max(MIN_BPM, baseline - DYNAMIC_LOWER_OFFSET)
    consecutive = 0
    alerts = []
    for idx in range(n_cal, len(readings)):
        bpm = readings[idx]
        if not (MIN_BPM <= bpm <= MAX_BPM):
            continue                      # failed estimate: app logs it, no state change
        absolute = bpm >= EMERGENCY_THRESHOLD
        absolute_low = bpm < LOW_BPM_THRESHOLD
        out = False
        if baseline is not None:
            out = bpm > upper or bpm < lower
            consecutive = consecutive + 1 if out else 0
        sustained = consecutive >= SUSTAINED_READINGS
        if absolute:
            alerts.append(idx)
        elif absolute_low:
            pass
        elif sustained:
            alerts.append(idx)
            consecutive = 0
    return dict(alert_indices=alerts, baseline=baseline)
