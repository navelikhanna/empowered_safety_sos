# Offline rPPG validation on UBFC-rPPG

Replaces the volunteer-recorded heart-rate data with the public UBFC-rPPG
dataset (Bobbia et al., 2019), so no new human-subject data collection or
institutional consent is needed.

## Run (POS: the paper's results)
    python evaluate_ubfc.py --root /path/to/DATASET_2 --split dev  --method pos --out results/dev_pos
    python evaluate_ubfc.py --root /path/to/DATASET_2 --split test --method pos --out results/test_pos
    python evaluate_ubfc.py --root /path/to/DATASET_2 --split test --method peak --out results/test_peak  # replaced baseline
Dev set = subjects 1, 10, 11 plus 7 drawn with `random.Random(0)`; the other 32 form the test set.
POS runs over each whole 15 s window (3 s step) and zero-pads the spectrum to 8n points, as the app does.
`--sweep --method pos` (window 10/15/20 s) is a post-hoc analysis; it must not be used to choose parameters.
Use Python 3.11 with `mediapipe==0.10.14`, `numpy<2` (newer MediaPipe builds crashed in our Colab run).

## Run (legacy red-channel script, `evaluate_ubfc_legacy.py`)
Easiest: copy the dataset into `../data/UBFC-rPPG/` (see `../data/README.md`) and run
`python evaluate_ubfc_legacy.py` (add `--dataset 1` for DATASET_1). The steps below use explicit paths instead.

1. Download from the dataset page (DATASET_2 is the main one; DATASET_1 optional).
2. `pip install -r requirements.txt`
3. `python evaluate_ubfc_legacy.py --root /path/to/DATASET_2 --out results_dataset2`
   `python evaluate_ubfc_legacy.py --root /path/to/DATASET_1 --out results_dataset1 --dataset 1`

Extra modes:
- `--sweep`: MAE / detection rate over a grid of threshold, refractory gap and
  smoothing values (plus the legacy 5/15-sample setting) -> `sweep_results.csv`.
  Face detection runs once; signals are cached in `signal_cache/`.
- `--legacy-params`: original fixed 5-sample smoothing / 15-sample gap.

## Outputs (in --out)
- `overall_summary.csv`: MAE, RMSE, bias, 95% limits of agreement, Pearson r,
  % within 5/10 BPM, detection rate, per-subject MAE mean/SD/bootstrap CI,
  low- vs high-motion breakdown, false/missed absolute-threshold alerts
- `per_subject.csv`: the same per subject (answers "individual errors")
- `windows.csv`: every 3 s reading with estimate, reference and motion score
- `bland_altman.png`

## Check before trusting the numbers
- Ground-truth parsing: DATASET_2 `ground_truth.txt` is parsed as row 1 = PPG,
  row 2 = HR, row 3 = time (s). DATASET_1 `gtdump.xmp` is parsed as
  col 0 = time (ms), col 1 = HR. Open one file per dataset and confirm.
- Face detector: MediaPipe's BlazeFace is used, not the TF.js build. Say so.
- The script reproduces the browser algorithm, not the browser pipeline
  (webcam compression, variable frame rate, TF.js box jitter).
- Run the script yourself and report what it prints; do not reuse old numbers.

## Other scripts in this folder
- `rppg_core.py` - shared estimator / alert-logic port (checked against script.js by
  `python ../tests/crosscheck_js_python.py`, needs Node).
- `synthetic_motion_experiment.py` - simulated false-negative / false-positive study vs
  motion artefact strength: `python synthetic_motion_experiment.py --n 100 --out synthetic_results`.
  It is a stress test of the algorithm on simulated signals, NOT evidence about real
  emergencies; the artefact model (0.5-4 Hz band-limited noise) is an assumption.
- `analyze_logs.py` - statistics from the app's exported CSVs (see its docstring).
  `python analyze_logs.py --sos sos_dispatch_log.csv --voice voice_trial_log.csv --hr hr_session_data.csv`


## MCD-rPPG (open license; recommended main heart-rate dataset)
`download_mcd_subset.py` fetches N subjects' frontal-webcam before/after videos and their
synchronised PPG; `evaluate_mcd.py` runs the same estimator and reports error per
condition (rest vs post-exercise), per-recording MAE with a bootstrap CI, limits of
agreement, a Bland-Altman plot and the alert-logic replay.

Reference HR comes from the dataset's PPG waveform (dominant frequency over the 10 s ending at
each window), not from a stored BPM value, and windows with a poor PPG spectrum are dropped and
counted. Two assumptions are printed for every recording and should be checked once: the PPG
sampling rate is *inferred* (samples / video duration, override with `--ppg-fs`), and
`ppg_sync` is assumed to start with the video. If the first run shows large errors for every
recording, doubt these two before the algorithm. The scripts were developed from the published
file layout and tested on synthetic fixtures, not on the real files.
