#!/usr/bin/env python3
"""
*** LEGACY (red-channel peak detection): evaluates the replaced estimator, NOT the POS method now in
script.js. Do not report its numbers as the app's performance. The POS evaluation used in the paper
(--method pos --split test) is validation/evaluate_ubfc.py. This file is the old red-channel script, kept only for the legacy tools. ***

Offline evaluation of the app's heart-rate algorithm on the public MCD-rPPG dataset
(Egorov et al., CC-BY-4.0): 600 subjects, each filmed BEFORE and AFTER physical activity,
with a synchronised PPG signal. 'before' = rest, 'after' = post-exercise, which matches
the rest / exercise conditions of the paper's Table 5 without recruiting anyone.

    python evaluate_mcd.py                         # defaults below
    python evaluate_mcd.py --max-subjects 40 --seconds 120

Expected layout (see ../data/README.md and download_mcd_subset.py):
    data/MCD-rPPG/video/<id>_FullHDwebcam_before.avi   <id>_FullHDwebcam_after.avi
    data/MCD-rPPG/ppg_sync/<id>_FullHDwebcam_before.txt   (first column = PPG samples)

Reference HR. The dataset gives a PPG waveform, not a BPM number, so the reference HR of
each window is the dominant frequency (0.7-3.0 Hz) of the PPG over the 10 s ending at
that window's end. Windows whose PPG spectrum has no clear peak (quality below
--min-ref-quality) are dropped, and how many were dropped is reported.

!! Assumptions you must check once (printed for every recording):
   * the PPG sampling rate is not hard-coded: it is inferred as
     (number of PPG samples) / (video duration). 30 Hz = one sample per frame, 60 Hz etc. are
     also plausible. Pass --ppg-fs to override if the dataset documentation says otherwise.
   * ppg_sync files start at the same instant as the video (that is what 'sync' means).
     If the per-recording agreement with the app looks random, that is the first thing to doubt.
Camera: frontal HD webcam by default (--camera). Frames are downscaled to 640 px wide, which is
close to what the browser app processes.
"""
import argparse
import glob
import os
import random
import re
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from evaluate_ubfc_legacy import (FaceBox, extract_signal, video_info, summarize, bootstrap_ci,  # noqa: E402
                           FPS, WINDOW, MIN_SAMPLES, STEP_SECONDS, EMERGENCY_THRESHOLD,
                           LEGACY, calculate_heart_rate, replay_alert_logic)

CONDITION = {"before": "rest", "after": "post_exercise"}
NAME_RE = re.compile(r"^(?P<id>.+?)_(?P<camera>[A-Za-z0-9]+)_(?P<state>before|after)$")


def read_ppg(path):
    """First whitespace-separated token of each line is an integer PPG sample."""
    vals = []
    with open(path) as f:
        for line in f:
            tok = line.split()
            if tok:
                try:
                    vals.append(float(tok[0]))
                except ValueError:
                    pass
    return np.asarray(vals)


def ppg_reference_hr(ppg, fs, t_end, win_s=10.0, lo=0.7, hi=3.0):
    """Dominant PPG frequency in the win_s seconds ending at t_end.
    Returns (bpm, quality) with quality = share of in-band power within +-0.15 Hz of the peak."""
    i1 = int(round(t_end * fs))
    i0 = max(0, i1 - int(round(win_s * fs)))
    seg = ppg[i0:i1]
    if len(seg) < int(4 * fs):
        return np.nan, 0.0
    seg = seg - seg.mean()
    seg = seg * np.hanning(len(seg))
    n = 1 << 15
    spec = np.abs(np.fft.rfft(seg, n)) ** 2
    fr = np.fft.rfftfreq(n, 1 / fs)
    band = (fr >= lo) & (fr <= hi)
    if not band.any() or spec[band].sum() <= 0:
        return np.nan, 0.0
    fpk = fr[band][np.argmax(spec[band])]
    near = band & (np.abs(fr - fpk) <= 0.15)
    return float(fpk * 60.0), float(spec[near].sum() / spec[band].sum())


def discover(root, camera, states):
    recs = {}
    for v in glob.glob(os.path.join(root, "video", f"*_{camera}_*.avi")):
        stem = os.path.splitext(os.path.basename(v))[0]
        m = NAME_RE.match(stem)
        if not m or m["state"] not in states:
            continue
        ppg = os.path.join(root, "ppg_sync", stem + ".txt")
        if os.path.exists(ppg):
            recs.setdefault(m["id"], []).append(dict(stem=stem, subject=m["id"], state=m["state"],
                                                     video=v, ppg=ppg))
    return recs


def get_signal(rec, detector, args, cache_dir):
    cp = os.path.join(cache_dir, f"{rec['stem']}_s{args.start:g}_d{args.seconds:g}_w{args.max_width}.npz")
    if os.path.exists(cp):
        z = np.load(cp)
        return z["red"], z["motion"], z["t"], float(z["fps"]), float(z["duration"])
    fps, dur = video_info(rec["video"])
    red, motion, t, vfps = extract_signal(rec["video"], detector, start_s=args.start,
                                          max_seconds=args.seconds, max_width=args.max_width)
    os.makedirs(cache_dir, exist_ok=True)
    np.savez(cp, red=red, motion=motion, t=t, fps=vfps, duration=dur)
    return red, motion, t, vfps, dur


def evaluate_recording(rec, detector, args, cache_dir, params):
    red, motion, t, vfps, dur = get_signal(rec, detector, args, cache_dir)
    if len(red) < MIN_SAMPLES:
        raise RuntimeError(f"only {len(red)} frames read (video shorter than --start?)")
    ppg = read_ppg(rec["ppg"])
    fs = args.ppg_fs if args.ppg_fs else (len(ppg) / dur if dur == dur and dur > 0 else np.nan)
    if not (10 <= fs <= 1000):
        raise RuntimeError(f"implausible PPG sampling rate {fs:.1f} Hz (len={len(ppg)}, video={dur:.1f}s)")
    rec["ppg_fs"], rec["video_fps"] = fs, vfps

    face_rate = float(np.mean(~np.isnan(red)))
    s = pd.Series(red).ffill().bfill().to_numpy()
    mo = pd.Series(motion).fillna(0).to_numpy()
    rows = []
    step = int(round(STEP_SECONDS * vfps))
    for end in range(max(MIN_SAMPLES, step), len(s) + 1, step):
        win = s[max(0, end - WINDOW):end]
        bpm = calculate_heart_rate(win, fps=vfps, **params)
        t_end = t[end - 1]
        ref, q = ppg_reference_hr(ppg, fs, t_end)
        rows.append(dict(recording=rec["stem"], subject=rec["subject"], state=rec["state"],
                         condition=CONDITION[rec["state"]], t=t_end, est_bpm=bpm, ref_bpm=ref,
                         ref_quality=q, motion=float(mo[max(0, end - WINDOW):end].mean()),
                         detected=bpm > 0))
    df = pd.DataFrame(rows)
    df["abs_err"] = (df.est_bpm - df.ref_bpm).abs().where(df.detected)
    df.attrs["face_rate"] = face_rate
    return df


def main():
    project = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=os.path.join(project, "data", "MCD-rPPG"))
    ap.add_argument("--out", default=os.path.join(project, "results", "mcd"))
    ap.add_argument("--camera", default="FullHDwebcam")
    ap.add_argument("--state", default="both", choices=["both", "before", "after"])
    ap.add_argument("--max-subjects", type=int, default=20)
    ap.add_argument("--seed", type=int, default=1, help="subject sampling seed")
    ap.add_argument("--start", type=float, default=10.0, help="seconds to skip at video start")
    ap.add_argument("--seconds", type=float, default=90.0, help="seconds analysed per recording")
    ap.add_argument("--max-width", type=int, default=640)
    ap.add_argument("--ppg-fs", type=float, default=None, help="override inferred PPG sampling rate (Hz)")
    ap.add_argument("--min-ref-quality", type=float, default=0.3)
    ap.add_argument("--motion-thresh", type=float, default=None)
    ap.add_argument("--legacy-params", action="store_true")
    args = ap.parse_args()

    states = ["before", "after"] if args.state == "both" else [args.state]
    recs = discover(args.root, args.camera, states)
    if args.state == "both":   # paired design: keep subjects that have both
        recs = {k: v for k, v in recs.items() if {r["state"] for r in v} == {"before", "after"}}
    if not recs:
        sys.exit(f"No usable recordings under {args.root}/video + ppg_sync for camera {args.camera}.\n"
                 "Run download_mcd_subset.py or copy files in - see data/README.md.")
    ids = sorted(recs)
    random.Random(args.seed).shuffle(ids)
    ids = sorted(ids[:args.max_subjects])
    chosen = [r for i in ids for r in sorted(recs[i], key=lambda r: r["state"])]
    os.makedirs(args.out, exist_ok=True)

    detector = FaceBox()
    print(f"Face detector: {detector.name}; subjects: {len(ids)}; recordings: {len(chosen)}")
    params = LEGACY if args.legacy_params else {}
    cache = os.path.join(args.out, "signal_cache")

    parts, skipped = [], []
    for rec in chosen:
        try:
            d = evaluate_recording(rec, detector, args, cache, params)
            parts.append(d)
            print(f"  {rec['stem']}: PPG {rec['ppg_fs']:.1f} Hz, video {rec['video_fps']:.1f} fps, "
                  f"face {d.attrs['face_rate']:.0%}, MAE={d.abs_err.mean():.2f} BPM, "
                  f"detected {d.detected.mean():.0%}")
        except Exception as e:
            skipped.append((rec["stem"], str(e)))
            print(f"  {rec['stem']}: SKIPPED ({e})")
    if not parts:
        sys.exit("Nothing could be evaluated.")
    allw = pd.concat(parts, ignore_index=True)
    n_all = len(allw)
    allw = allw[allw.ref_quality >= args.min_ref_quality].copy()
    dropped = n_all - len(allw)

    thr = args.motion_thresh if args.motion_thresh is not None else float(allw.motion.median())
    allw["high_motion"] = allw.motion > thr
    allw.to_csv(os.path.join(args.out, "windows.csv"), index=False)

    per_rec = pd.DataFrame([dict(recording=k, subject=g.subject.iloc[0], condition=g.condition.iloc[0],
                                 **summarize(g)) for k, g in allw.groupby("recording")])
    per_rec.to_csv(os.path.join(args.out, "per_recording.csv"), index=False)

    rows = []
    for name, g in [("ALL", allw)] + list(allw.groupby("condition")):
        pr = per_rec if name == "ALL" else per_rec[per_rec.condition == name]
        lo, hi = bootstrap_ci(pr.MAE)
        rows.append(dict(condition=name, n_subjects=g.subject.nunique(), n_recordings=g.recording.nunique(),
                         ref_hr_mean=g.ref_bpm.mean(), ref_hr_min=g.ref_bpm.min(), ref_hr_max=g.ref_bpm.max(),
                         recording_MAE_mean=pr.MAE.mean(), recording_MAE_SD=pr.MAE.std(ddof=1),
                         recording_MAE_CI95_low=lo, recording_MAE_CI95_high=hi, **summarize(g)))
    by_cond = pd.DataFrame(rows)
    by_cond.to_csv(os.path.join(args.out, "overall_by_condition.csv"), index=False)

    # alert-logic replay: an alert is 'unjustified' unless the PPG reference HR was >= 130 BPM
    rp = []
    for d in parts:
        d = d[d.ref_quality >= args.min_ref_quality]
        if d.empty:
            continue
        res = replay_alert_logic(list(d.est_bpm.fillna(0).to_numpy()))
        idx = [i for i in res["alert_indices"] if i < len(d)]
        unj = sum(1 for i in idx if not (d.ref_bpm.iloc[i] >= EMERGENCY_THRESHOLD))
        rp.append(dict(recording=d.recording.iloc[0], condition=d.condition.iloc[0], baseline_bpm=res["baseline"],
                       n_alert_readings=len(idx), n_unjustified=unj, minutes=float(d.t.max() - d.t.min()) / 60.0))
    replay = pd.DataFrame(rp)
    replay.to_csv(os.path.join(args.out, "alert_replay.csv"), index=False)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        v = allw[allw.detected].dropna(subset=["ref_bpm"])
        plt.figure(figsize=(6, 4))
        for c, col in (("rest", "tab:blue"), ("post_exercise", "tab:red")):
            u = v[v.condition == c]
            plt.scatter((u.est_bpm + u.ref_bpm) / 2, u.est_bpm - u.ref_bpm, s=8, alpha=.4, c=col, label=c)
        d_all = v.est_bpm - v.ref_bpm
        plt.axhline(d_all.mean(), color="k")
        for k in (-1.96, 1.96):
            plt.axhline(d_all.mean() + k * d_all.std(ddof=1), color="gray", ls="--")
        plt.xlabel("Mean of rPPG and PPG-reference HR (BPM)"); plt.ylabel("rPPG - reference (BPM)")
        plt.title("Bland-Altman, MCD-rPPG"); plt.legend(); plt.tight_layout()
        plt.savefig(os.path.join(args.out, "bland_altman.png"), dpi=200)
    except Exception as e:
        print("plot skipped:", e)

    pd.set_option("display.width", 220, "display.max_columns", 40)
    print("\n=== BY CONDITION (reference = PPG dominant frequency) ===")
    show = ["condition", "n_subjects", "n_recordings", "n_windows", "detection_rate", "MAE", "bias", "SD_err",
            "LoA_low", "LoA_high", "pearson_r", "within_5bpm", "recording_MAE_mean", "recording_MAE_SD",
            "recording_MAE_CI95_low", "recording_MAE_CI95_high", "ref_hr_mean"]
    print(by_cond[[c for c in show if c in by_cond]].round(3).T.to_string(header=False))
    print(f"\nwindows dropped for poor PPG reference quality: {dropped} of {n_all}")
    if len(replay):
        for c, g in replay.groupby("condition"):
            print(f"alert replay [{c}]: {int(g.n_unjustified.sum())} unjustified alert readings in "
                  f"{g.minutes.sum():.1f} min ({len(g)} recordings)")
    if skipped:
        print(f"\nskipped recordings: {len(skipped)} (see messages above)")
    print(f"\nResults written to {args.out}/   Cite: Egorov et al., 'Gaze into the Heart' (MCD-rPPG), CC-BY-4.0.")


if __name__ == "__main__":
    main()
