#!/usr/bin/env python3
"""
*** LEGACY (red-channel peak detection): evaluates the replaced estimator, NOT the POS method now in
script.js. Do not report its numbers as the app's performance. The POS evaluation used in the paper
(--method pos --split test) is validation/evaluate_ubfc.py. This file is the old red-channel script, kept only for the legacy tools. ***

Controlled SYNTHETIC experiment: how do the HR estimator and the emergency
alert logic behave as motion artefact grows?

Why this exists
---------------
Reviewers asked for false-negative / false-positive rates under motion and for
the *emergency-triggering* behaviour (not only HR estimation error). Real
distress/motion recordings with ground truth are not available (and would need
ethics approval), so this script simulates a forehead red-channel signal with a
known HR trajectory plus motion artefact of controlled strength, and runs the
SAME estimator and alert logic as script.js (via rppg_core.py, which
tests/crosscheck_js_python.py verifies against script.js).

What it can and cannot claim
----------------------------
* It characterises the *algorithm's* sensitivity to artefact in a simulation.
* It is NOT evidence about real emergencies, real motion, real skin tones or
  real cameras. Report it as a simulation / stress test, never as clinical or
  field validation. The artefact model (band-limited noise, 0.5-4 Hz, i.e.
  overlapping the pulse band) is an assumption; change --artifact-band to test others.

Scenarios (each simulated N times per motion level)
---------------------------------------------------
  rest        HR stays near baseline            -> any alert is a FALSE POSITIVE
  exercise    HR drifts up to ~105 and stays    -> alert here is a false positive
                                                   for ordinary exertion
  emergency   HR jumps to 140 at t=60 s         -> no alert within --detect-window
                                                   seconds is a FALSE NEGATIVE
Calibration (first 30 s) is artefact-free by default (user holds still while
calibrating); use --motion-in-calibration to test the opposite.

Motion level = RMS of artefact / RMS of the pulse component (0 = none,
1 = artefact as strong as the pulse).

Usage:  python synthetic_motion_experiment.py --n 100 --out synthetic_results
"""
import argparse
import os
import numpy as np
import pandas as pd
from rppg_core import (calculate_heart_rate, replay_alert_logic, STEP_SECONDS,
                       WINDOW, MIN_SAMPLES, MIN_BPM, MAX_BPM)

SESSION_S = 150
CAL_S = 30
EVENT_S = 60


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def hr_profile(scenario, t, baseline):
    hr = np.full_like(t, float(baseline))
    if scenario == "exercise":
        # smooth rise to baseline+30 between 60 s and 90 s
        r = np.clip((t - EVENT_S) / 30.0, 0, 1)
        hr = baseline + 30 * r
    elif scenario == "emergency":
        r = np.clip((t - EVENT_S) / 3.0, 0, 1)          # ~3 s ramp to 140
        hr = baseline + (140 - baseline) * r
    return hr


def pulse(hr_bpm, fps, rng):
    """Pulse-like waveform with beat-to-beat variability (random-walk HR jitter)."""
    jitter = np.cumsum(rng.normal(0, 0.02, len(hr_bpm)))
    jitter -= np.linspace(jitter[0], jitter[-1], len(jitter))       # keep mean HR
    f = (hr_bpm + 1.5 * jitter) / 60.0
    phase = 2 * np.pi * np.cumsum(f) / fps
    return np.sin(phase) + 0.35 * np.sin(2 * phase + 0.8)


def band_noise(n, fps, lo, hi, rng):
    x = rng.normal(size=n)
    X = np.fft.rfft(x)
    fr = np.fft.rfftfreq(n, 1 / fps)
    X[(fr < lo) | (fr > hi)] = 0
    y = np.fft.irfft(X, n)
    return y / (y.std() + 1e-12)


def simulate(scenario, motion_level, fps, rng, band, motion_in_cal):
    n = SESSION_S * fps
    t = np.arange(n) / fps
    baseline = rng.uniform(62, 88)
    p = pulse(hr_profile(scenario, t, baseline), fps, rng)
    sensor = rng.normal(0, 0.08, n)                                   # camera noise
    art = band_noise(n, fps, *band, rng) * motion_level * p.std()
    art = art * (1.0 if motion_in_cal else (t >= CAL_S))              # still during calibration
    sig = 120 + 2.0 * (p + sensor + art)
    return sig, baseline, t


def readings_from_signal(sig, fps):
    step = int(round(STEP_SECONDS * fps))
    est, t_end = [], []
    for end in range(max(MIN_SAMPLES, step), len(sig) + 1, step):
        est.append(calculate_heart_rate(sig[max(0, end - WINDOW):end], fps=fps))
        t_end.append(end / fps)
    return np.array(est), np.array(t_end)


def run(args):
    rng = np.random.default_rng(args.seed)
    levels = [float(x) for x in args.levels.split(",")]
    band = tuple(float(x) for x in args.artifact_band.split(","))
    est_rows, sess_rows = [], []
    for scen in ("rest", "exercise", "emergency"):
        for lvl in levels:
            for k in range(args.n):
                sig, base, _ = simulate(scen, lvl, args.fps, rng, band, args.motion_in_calibration)
                est, tend = readings_from_signal(sig, args.fps)
                true_hr = hr_profile(scen, tend, base)
                valid = est > 0
                err = np.abs(est - true_hr)
                post = tend > CAL_S
                est_rows.append(dict(scenario=scen, motion=lvl, n_windows=int(post.sum()),
                                     n_valid=int((valid & post).sum()),
                                     abs_err_sum=float(err[valid & post].sum()),
                                     n_within5=int(((err <= 5) & valid & post).sum())))
                res = replay_alert_logic(list(est))
                times = [tend[i] for i in res["alert_indices"]]
                alert_any = len(times) > 0
                if scen == "emergency":
                    in_win = [x for x in times if EVENT_S <= x <= EVENT_S + args.detect_window]
                    hit = len(in_win) > 0
                    delay = (in_win[0] - EVENT_S) if hit else np.nan
                    early = any(x < EVENT_S for x in times)   # spurious alert before the event
                else:
                    hit, delay, early = np.nan, np.nan, alert_any
                sess_rows.append(dict(scenario=scen, motion=lvl, alert_any=alert_any,
                                      detected_in_window=hit, delay_s=delay,
                                      alert_before_event=early, n_alerts=len(times)))
    est_df = pd.DataFrame(est_rows).groupby(["scenario", "motion"]).sum(numeric_only=True).reset_index()
    est_df["detection_rate"] = est_df.n_valid / est_df.n_windows
    est_df["MAE_bpm"] = est_df.abs_err_sum / est_df.n_valid.replace(0, np.nan)
    est_df["within5_of_valid"] = est_df.n_within5 / est_df.n_valid.replace(0, np.nan)
    sess = pd.DataFrame(sess_rows)

    out = []
    for (scen, lvl), g in sess.groupby(["scenario", "motion"]):
        n = len(g)
        row = dict(scenario=scen, motion=lvl, n_sessions=n)
        if scen == "emergency":
            k = int(g.detected_in_window.sum())
            row.update(sensitivity=k / n, sens_CI_low=wilson(k, n)[0], sens_CI_high=wilson(k, n)[1],
                       false_negative_rate=1 - k / n,
                       median_delay_s=float(g.delay_s.median()),
                       spurious_alert_before_event=float(g.alert_before_event.mean()))
        else:
            k = int(g.alert_any.sum())
            row.update(false_alert_session_rate=k / n,
                       fa_CI_low=wilson(k, n)[0], fa_CI_high=wilson(k, n)[1])
        out.append(row)
    summary = pd.DataFrame(out).merge(
        est_df[["scenario", "motion", "detection_rate", "MAE_bpm", "within5_of_valid"]],
        on=["scenario", "motion"])
    os.makedirs(args.out, exist_ok=True)
    summary.to_csv(os.path.join(args.out, "synthetic_summary.csv"), index=False)
    sess.to_csv(os.path.join(args.out, "synthetic_sessions.csv"), index=False)
    pd.set_option("display.width", 200, "display.max_columns", 20)
    print(f"SYNTHETIC stress test (n={args.n} sessions per cell, fps={args.fps}, seed={args.seed}, "
          f"artifact band={band} Hz, motion_in_calibration={args.motion_in_calibration})")
    for scen in ("rest", "exercise", "emergency"):
        print(f"\n--- {scen} ---")
        print(summary[summary.scenario == scen].dropna(axis=1, how="all")
              .drop(columns=["scenario"]).round(3).to_string(index=False))
    print(f"\nWritten to {args.out}/   (simulation only - not field evidence)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=100, help="simulated sessions per scenario x motion level")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--levels", default="0,0.25,0.5,1,2,4", help="artefact RMS / pulse RMS")
    ap.add_argument("--artifact-band", default="0.5,4.0", help="low,high Hz of motion artefact")
    ap.add_argument("--detect-window", type=float, default=30.0,
                    help="seconds after the emergency onset within which an alert counts as detected")
    ap.add_argument("--motion-in-calibration", action="store_true")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="synthetic_results")
    run(ap.parse_args())
