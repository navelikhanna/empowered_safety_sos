console.log("JS file loaded");

// ============================================================
// INITIALIZE - Set up event listeners when page loads
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    loadAndDisplayContacts();
    document.getElementById('addContactBtn').addEventListener('click', addContact);
    document.getElementById('startBtn').addEventListener('click', startListening);

    const exportHRBtn = document.getElementById('exportHRDataBtn');
    if (exportHRBtn) exportHRBtn.addEventListener('click', exportHRSessionData);

    const exportVoiceBtn = document.getElementById('exportVoiceDataBtn');
    if (exportVoiceBtn) exportVoiceBtn.addEventListener('click', exportVoiceTrialLog);

    const exportSOSBtn = document.getElementById('exportSOSDataBtn');
    if (exportSOSBtn) exportSOSBtn.addEventListener('click', exportSOSLatencyLog);

    const recordRefBtn = document.getElementById('recordReferenceBtn');
    if (recordRefBtn) recordRefBtn.addEventListener('click', recordReferenceReading);
});

// ============================================================
// EMERGENCY CONTACTS MANAGEMENT
// ============================================================

// Reads from localStorage and adds a "Remove" button
function loadAndDisplayContacts() {
    const contacts = JSON.parse(localStorage.getItem('emergencyContacts')) || [];
    const contactList = document.getElementById('contactList');
    contactList.innerHTML = ''; // Clear the list first

    if (contacts.length === 0) {
        contactList.innerHTML = '<li style="opacity: 0.6;">No contacts added yet</li>';
        return;
    }

    contacts.forEach((contact, index) => {
        let li = document.createElement("li");

        let contactInfo = document.createElement("span");
        contactInfo.textContent = `${contact.name}: ${contact.number}`;

        let removeBtn = document.createElement("button");
        removeBtn.textContent = "Remove";
        removeBtn.className = 'delete-btn';

        // This line connects the button to the delete function
        removeBtn.onclick = () => deleteContact(index);

        li.appendChild(contactInfo);
        li.appendChild(removeBtn);
        contactList.appendChild(li);
    });
}

// Deletes a contact from localStorage
function deleteContact(index) {
    let contacts = JSON.parse(localStorage.getItem('emergencyContacts')) || [];
    contacts.splice(index, 1); // Remove the contact at the specified index
    localStorage.setItem('emergencyContacts', JSON.stringify(contacts));
    loadAndDisplayContacts(); // Refresh the list
}

// --- Basic E.164 phone number validation ---
// This is deliberately lightweight (no external library / bundler in this
// project) but goes beyond a bare "+" check: it requires a plausible
// country-code-prefixed number of 8-15 digits total, per the E.164 format.
// NOTE: this is still only a format check, not proof the number is real,
// active, or reachable -- described accurately as "basic input sanitization"
// in the paper, not "number verification".
function isPlausibleE164(number) {
    return /^\+[1-9]\d{7,14}$/.test(number);
}

// Saves a new contact to localStorage
function addContact() {
    const name = document.getElementById("contactName").value.trim();
    const numberRaw = document.getElementById("contactNumber").value.trim();

    if (!name || !numberRaw) {
        alert("Please enter both name and number.");
        return;
    }

    // Ensure number has the + prefix if not present
    let formattedNumber = numberRaw.replace(/[\s()-]/g, '');
    if (!formattedNumber.startsWith('+')) {
        formattedNumber = '+' + formattedNumber;
    }

    if (!isPlausibleE164(formattedNumber)) {
        alert("That doesn't look like a valid international number (e.g. +919876543210). Please include the country code and only digits.");
        return;
    }

    const newContact = { name: name, number: formattedNumber };
    let contacts = JSON.parse(localStorage.getItem('emergencyContacts')) || [];
    contacts.push(newContact);
    localStorage.setItem('emergencyContacts', JSON.stringify(contacts));
    loadAndDisplayContacts();
    document.getElementById("contactName").value = "";
    document.getElementById("contactNumber").value = "";
}

// ============================================================
// SOS FUNCTIONALITY (with client-side latency logging)
// ============================================================

// Every SOS dispatch attempt (timestamp, success/failure, latency) is
// pushed here so results can be exported and summarized with real
// descriptive statistics (mean/SD, success-rate confidence interval)
// instead of being typed in from memory after informal testing.
let sosLatencyLog = [];

// Backend URL. Override before script.js loads with
//   <script>window.SOS_API_BASE = "https://your-host";</script>
const API_BASE = window.SOS_API_BASE || "http://127.0.0.1:5000";

// Geolocation options. enableHighAccuracy stays false so the app keeps using
// network-assisted location; set it to true to request a GNSS fix instead.
// maximumAge: 0 forces a fresh fix so the logged accuracy is for THIS dispatch.
const GEO_OPTIONS = { enableHighAccuracy: false, timeout: 20000, maximumAge: 0 };

// Wraps getCurrentPosition and also reports how long the fix took and the
// accuracy radius (metres, 68 % confidence per the Geolocation spec) the
// browser claims for it. The claimed radius is NOT ground-truth error.
function getLocationFix(onSuccess, onError) {
    const t0 = performance.now();
    navigator.geolocation.getCurrentPosition(
        position => onSuccess(position, Math.round(performance.now() - t0)),
        onError,
        GEO_OPTIONS
    );
}

// Network context for the latency log (Chromium only; blank elsewhere).
function networkInfo() {
    const c = navigator.connection || {};
    return {
        net_effective_type: c.effectiveType || "",
        net_rtt_ms: c.rtt !== undefined ? c.rtt : "",
        net_downlink_mbps: c.downlink !== undefined ? c.downlink : ""
    };
}

// meta = { source, accuracy_m, geo_fix_ms } describes how the SOS was
// triggered and how good the location fix was.
function dispatchSOSToContacts(contacts, lat, lon, onEachSettled, meta = {}) {
    contacts.forEach(contact => {
        const t0 = performance.now();
        fetch(`${API_BASE}/sos`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                number: contact.number,
                latitude: lat,
                longitude: lon,
                accuracy_m: meta.accuracy_m,
                trigger_source: meta.source || "unknown"
            })
        })
        .then(response => response.json().then(body => ({ ok: response.ok, body })))
        .then(({ ok, body }) => {
            const latencyMs = performance.now() - t0;
            sosLatencyLog.push({
                timestamp: new Date().toISOString(),
                trigger_source: meta.source || "unknown",
                contact: contact.name,
                status: ok ? "success" : "error",
                latency_ms: Math.round(latencyMs),
                server_latency_ms: body.server_latency_ms !== undefined ? body.server_latency_ms : "",
                geo_accuracy_m: meta.accuracy_m !== undefined ? Math.round(meta.accuracy_m) : "",
                geo_fix_ms: meta.geo_fix_ms !== undefined ? meta.geo_fix_ms : "",
                ...networkInfo(),
                twilio_sid: body.sid || "",
                error: ok ? "" : (body.message || "")
            });
            if (onEachSettled) onEachSettled(ok, contact);
        })
        .catch(error => {
            const latencyMs = performance.now() - t0;
            sosLatencyLog.push({
                timestamp: new Date().toISOString(),
                trigger_source: meta.source || "unknown",
                contact: contact.name,
                status: "network_error",
                latency_ms: Math.round(latencyMs),
                server_latency_ms: "",
                geo_accuracy_m: meta.accuracy_m !== undefined ? Math.round(meta.accuracy_m) : "",
                geo_fix_ms: meta.geo_fix_ms !== undefined ? meta.geo_fix_ms : "",
                ...networkInfo(),
                twilio_sid: "",
                error: String(error)
            });
            if (onEachSettled) onEachSettled(false, contact);
        });
    });
}

function exportSOSLatencyLog() {
    downloadCSV(sosLatencyLog, "sos_dispatch_log.csv");
}

// Non-blocking status line (alert() would stall an automatic dispatch until
// someone clicked OK).
function showSOSStatus(msg) {
    const el = document.getElementById("statusMessage");
    if (el) { el.innerText = msg; el.style.display = "block"; }
    console.log("[SOS]", msg);
}

// source: "manual" asks for confirmation first. Automatic sources
// ("hr_fusion", "hr_confirmed", "hr_timeout") were already authorised by the
// fusion gate / countdown, so they must not block on another confirm().
function requestLocation(source = "manual") {
    const contacts = JSON.parse(localStorage.getItem('emergencyContacts')) || [];
    if (contacts.length === 0) {
        // alert() would freeze an automatic (cardiac / fusion) dispatch, so only
        // the manual path blocks; automatic paths report in the status line.
        if (source === "manual") alert("No emergency contacts found. Please add a contact first.");
        else showSOSStatus("SOS NOT sent: no emergency contacts saved.");
        return;
    }

    const proceed = source === "manual"
        ? confirm("This will send a real SOS to your contacts. Proceed?")
        : true;
    if (proceed) {
        getLocationFix((position, fixMs) => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            const meta = { source, accuracy_m: position.coords.accuracy, geo_fix_ms: fixMs };
            showSOSStatus(`Location acquired (browser-reported accuracy ~${Math.round(position.coords.accuracy)} m). Dispatching SOS to ${contacts.length} contact(s)...`);

            dispatchSOSToContacts(contacts, lat, lon, (ok, contact) => {
                console.log(`Server response for ${contact.name}: ${ok ? "sent" : "failed"}`);
            }, meta);

        }, error => {
            console.error("Geolocation error:", error);
            showSOSStatus("Could not get your location - SOS NOT sent.");
        });
    }
}

// ============================================================
// VOICE ACTIVATION
// ============================================================

// Fusion gate reads this to know whether a distress keyword was heard
// recently. Cleared automatically after VOICE_FLAG_WINDOW_MS.
let voiceFlagTimestamp = null;
const VOICE_FLAG_WINDOW_MS = 20000; // 20 s, matches the manuscript's fusion window

function isVoiceFlagActive() {
    return voiceFlagTimestamp !== null && (Date.now() - voiceFlagTimestamp) < VOICE_FLAG_WINDOW_MS;
}

// Every recognized (or explicitly rejected) utterance is logged here so
// voice-trial accuracy can be computed from real trial records, including
// a Wilson/Clopper-Pearson confidence interval, rather than a manually
// tallied percentage.
let voiceTrialLog = [];

// Identifies this page load so trials from one sitting can be grouped
// (trial independence: same speaker / same session / same noise setting).
const VOICE_SESSION_ID = "s" + Date.now().toString(36);

function voiceTrialContext() {
    const spk = document.getElementById('voiceSpeakerId');
    const cond = document.getElementById('voiceNoiseCondition');
    const exp = document.getElementById('voiceExpectedKeyword');
    return {
        session_id: VOICE_SESSION_ID,
        speaker_id: spk && spk.value.trim() ? spk.value.trim() : "unspecified",
        noise_condition: cond ? cond.value : "unspecified",
        expected_keyword: exp ? exp.value : "unspecified"
    };
}

function exportVoiceTrialLog() {
    downloadCSV(voiceTrialLog, "voice_trial_log.csv");
}

// One-time disclosure: the Web Speech API streams audio to a cloud
// recognition service in Chromium-based browsers. We tell the user this
// before the microphone is ever activated, matching what the paper now
// states in the privacy section, instead of silently implying local-only
// processing.
function showVoiceDisclosureIfNeeded() {
    if (localStorage.getItem('voiceDisclosureAcknowledged') === 'true') return true;
    const accepted = confirm(
        "Voice activation uses your browser's built-in speech recognition. " +
        "In Chrome/Edge, this sends short audio clips to a cloud speech " +
        "recognition service (not processed on this device) to detect the " +
        "keyword. Continue?"
    );
    if (accepted) {
        localStorage.setItem('voiceDisclosureAcknowledged', 'true');
    }
    return accepted;
}

function startListening() {
    const statusElement = document.getElementById("statusMessage");
    const startBtn = document.getElementById("startBtn");
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        alert("Sorry, your browser does not support speech recognition.");
        return;
    }

    if (!showVoiceDisclosureIfNeeded()) {
        statusElement.innerText = "Voice activation cancelled.";
        statusElement.style.display = "block";
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();
    startBtn.textContent = "Listening...";
    startBtn.disabled = true;

    recognition.onresult = (event) => {
        const spoken = event.results[0][0].transcript.toLowerCase();
        const commands = ["help", "emergency", "stop"];
        let matched = null;

        for (const cmd of commands) {
            if (spoken.includes(cmd)) {
                matched = cmd;
                break;
            }
        }

        voiceTrialLog.push({
            timestamp: new Date().toISOString(),
            ...voiceTrialContext(),
            transcript: spoken,
            confidence: Math.round(event.results[0][0].confidence * 1000) / 1000,
            matched_keyword: matched || "none"
        });

        if (matched === "help" || matched === "emergency") {
            voiceFlagTimestamp = Date.now(); // feeds the sensor-fusion gate
            if (confirm("SOS command received. Send your location to emergency contacts?")) {
                triggerVoiceSOS();
            } else {
                statusElement.innerText = "SOS cancelled by user.";
                statusElement.style.display = "block";
            }
        } else if (matched === "stop") {
            statusElement.innerText = "Action cancelled.";
            statusElement.style.display = "block";
        } else {
            statusElement.innerText = `Heard "${spoken}" - no matching keyword.`;
            statusElement.style.display = "block";
        }
    };

    recognition.onerror = (event) => {
        // Log recognition failures too (no-speech, not-allowed, network ...),
        // otherwise failed trials silently vanish and accuracy is overstated.
        voiceTrialLog.push({
            timestamp: new Date().toISOString(),
            ...voiceTrialContext(),
            transcript: "",
            confidence: "",
            matched_keyword: "error:" + event.error
        });
        statusElement.innerText = `Error: ${event.error}`;
        statusElement.style.display = "block";
    };

    recognition.onend = () => {
        startBtn.textContent = "Start Listening";
        startBtn.disabled = false;
    };
}

function triggerVoiceSOS() {
    const statusElement = document.getElementById("statusMessage");
    const contacts = JSON.parse(localStorage.getItem('emergencyContacts')) || [];
    if (contacts.length === 0) {
        statusElement.innerText = "No contacts found.";
        statusElement.style.display = "block";
        return;
    }
    statusElement.innerText = "Accessing location...";
    statusElement.style.display = "block";
    getLocationFix((position, fixMs) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        const meta = { source: "voice", accuracy_m: position.coords.accuracy, geo_fix_ms: fixMs };
        statusElement.innerText = `Sending SOS to ${contacts.length} contact(s)...`;
        dispatchSOSToContacts(contacts, lat, lon, (ok) => {
            statusElement.innerText = ok ? "SOS sent successfully!" : "Error connecting to server.";
        }, meta);
    }, () => {
        statusElement.innerText = "Could not get your location.";
    });
}

function alertPolice() {
    // NOTE: still a placeholder, as disclosed in the paper's Limitations
    // section -- no real emergency-services API is called here. A working
    // Twilio call to a placeholder number exists in archive/sos.js if this
    // is wired up in a future version.
    alert("Placeholder: no real police dispatch is implemented in this prototype.");
}

// ============================================================
// HEART RATE DETECTION WITH TENSORFLOW.JS FACE DETECTION
// Pulse extraction uses the POS (plane-orthogonal-to-skin) rPPG projection on
// the mean RGB of a central-face region, over a 15 s window stepped every 3 s
// (see calculateHeartRate). The earlier red-channel peak-detection method was
// replaced after the offline UBFC-rPPG evaluation (see manuscript Section 5.4).
// Implements: 30s calibration -> personalized dynamic band -> sustained
// anomaly detection -> sensor-fusion gate -> SOS dispatch, matching the
// activity/state diagrams. Absolute thresholds (>=130 / <60 BPM) remain a
// final, independent safety check regardless of calibration state.
// ============================================================

let hrStream = null;
let hrAnimationFrame = null;
let hrStartTime = null;
let faceDetectionModel = null;

// PPG analysis variables
let rgbSamples = [];
let bpmReadings = [];          // readings taken during the CALIBRATION phase
let postCalibrationReadings = []; // {bpm, motion, timestamp} taken after calibration
const MEASUREMENT_DURATION = 20;      // legacy fixed-window fallback, still used if calibration fails
const CALIBRATION_DURATION = 30;      // seconds, matches Fig. 2/3
const FPS = 30;                       // nominal fallback only; the achieved rate is measured per window
const READING_INTERVAL_MS = 3000;     // one BPM estimate per 3 s (see cadence gate in captureFrames)
// --- POS rPPG constants (frozen before the held-out UBFC-rPPG test run) ---
// Keep in lock-step with validation/rppg_core.py (tests/crosscheck_js_python.py checks it).
const POS_WINDOW_S = 15;              // analysis window length
const POS_MIN_SPAN_S = 14.25;         // a window must cover >= 95 % of POS_WINDOW_S
const POS_RESAMPLE_HZ = 30;           // browser timestamps are irregular -> resample to a uniform grid
const POS_FREQ_LO_HZ = 0.7;           // 42 BPM
const POS_FREQ_HI_HZ = 3.0;           // 180 BPM
const POS_ZERO_PAD = 8;               // spectrum evaluated at 8x the window length (frequency grid only)
const ROI_X0 = 0.15, ROI_X1 = 0.85;   // central-face ROI, fractions of the BlazeFace box width
const ROI_Y0 = 0.30, ROI_Y1 = 0.85;   // ... and height
const SAMPLE_KEEP_S = 20;             // samples older than this are discarded (bounds memory)
// POS always returns a spectral peak, so there is no "no estimate" state and
// no quality check: a corrupted window yields a confident but wrong value.
const MIN_BPM = 60 * POS_FREQ_LO_HZ;  // 42
const MAX_BPM = 60 * POS_FREQ_HI_HZ;  // 180
const BAND_FLOOR_BPM = 50;            // floor of the personal dynamic band (unchanged)
const EMERGENCY_THRESHOLD = 130;      // absolute, independent final check
const LOW_BPM_THRESHOLD = 60;         // absolute, independent final check
const DYNAMIC_UPPER_OFFSET = 40;      // baseline + 40 BPM
const DYNAMIC_LOWER_OFFSET = 20;      // baseline - 20 BPM
const SUSTAINED_ANOMALY_READINGS = 3; // consecutive out-of-band readings (3 s cadence; successive 15 s windows overlap by 80 %)

// Face detection / motion variables
let faceDetected = false;
let noFaceFrameCount = 0;
const MAX_NO_FACE_FRAMES = 30;
let prevFaceCenter = null;

// Calibration / dynamic threshold state
let calibrationComplete = false;
let baselineBpm = null;
let dynamicUpperBound = null;
let dynamicLowerBound = null;
let consecutiveOutOfBand = 0;
let lastReadingAtMs = -Infinity;   // elapsed-ms of the last BPM estimate (cadence gate)
let lastAchievedFps = FPS;         // measured frame rate of the most recent window
let sessionLog = []; // full per-reading log for CSV export
let referenceBpmLog = []; // paired manual reference-device readings, if entered

// Test-condition context (subject / condition / distance / lighting) is read
// from the testing-tools inputs and stamped on every HR log row.
function hrContext() {
    const v = id => { const e = document.getElementById(id); return e && e.value !== "" ? e.value : ""; };
    return {
        subject_id: v('hrSubjectId'),
        condition: v('hrCondition'),
        distance_cm: v('hrDistanceCm'),
        lux: v('hrLux')
    };
}
function logHR(row) { sessionLog.push({ ...hrContext(), ...row }); }

// BlazeFace options we set explicitly so they are logged. All other options
// (input size, iouThreshold) are the library defaults and are not overridden.
const BLAZEFACE_CONFIG = { maxFaces: 1, scoreThreshold: 0.75 };

// One metadata row per session: what a reader needs to reproduce the setup
// (browser, camera device + the settings the browser actually granted,
// algorithm constants).
function logSessionMetadata(stream) {
    const track = stream && stream.getVideoTracks ? stream.getVideoTracks()[0] : null;
    const st = track && track.getSettings ? track.getSettings() : {};
    logHR({
        timestamp: new Date().toISOString(),
        phase: "metadata",
        status: "session_start",
        user_agent: navigator.userAgent,
        camera_label: track ? track.label : "",
        cam_width: st.width || "", cam_height: st.height || "", cam_frameRate_setting: st.frameRate || "",
        requested_resolution: "640x480 (ideal)",
        blazeface_maxFaces: BLAZEFACE_CONFIG.maxFaces,
        blazeface_scoreThreshold: BLAZEFACE_CONFIG.scoreThreshold,
        hr_method: "POS", pos_window_s: POS_WINDOW_S, pos_resample_hz: POS_RESAMPLE_HZ,
        pos_band_hz: POS_FREQ_LO_HZ + "-" + POS_FREQ_HI_HZ, pos_zero_pad: POS_ZERO_PAD,
        roi_x: ROI_X0 + "-" + ROI_X1, roi_y: ROI_Y0 + "-" + ROI_Y1,
        reading_interval_ms: READING_INTERVAL_MS,
        calibration_s: CALIBRATION_DURATION
    });
}

async function startHeartRateDetection() {
    const video = document.getElementById('hrVideo');
    const canvas = document.getElementById('hrCanvas');
    const resultsDiv = document.getElementById('healthResults');
    const startBtn = document.getElementById('startHRBtn');
    const stopBtn = document.getElementById('stopHRBtn');

    // Reset previous session
    rgbSamples = [];
    bpmReadings = [];
    postCalibrationReadings = [];
    sessionLog = [];
    referenceBpmLog = [];
    hrStartTime = Date.now();
    faceDetected = false;
    noFaceFrameCount = 0;
    prevFaceCenter = null;
    calibrationComplete = false;
    baselineBpm = null;
    dynamicUpperBound = null;
    dynamicLowerBound = null;
    consecutiveOutOfBand = 0;
    lastReadingAtMs = -Infinity;
    lastAchievedFps = FPS;

    document.getElementById('hrStatus').innerText = "Loading face detection model...";

    try {
        if (!faceDetectionModel) {
            faceDetectionModel = await blazeface.load(BLAZEFACE_CONFIG);
            console.log("Face detection model loaded successfully!");
        }
    } catch (error) {
        console.error("Failed to load face detection model:", error);
        alert("Failed to load face detection. Please check your internet connection and try again.");
        return;
    }

    try {
        hrStream = await navigator.mediaDevices.getUserMedia({
            video: {
                facingMode: "user",
                width: { ideal: 640 },
                height: { ideal: 480 }
            }
        });

        logSessionMetadata(hrStream);
        video.srcObject = hrStream;
        video.style.display = "block";
        resultsDiv.style.display = "block";
        startBtn.style.display = "none";
        stopBtn.style.display = "block";

        document.getElementById('heartRate').innerText = "--";
        document.getElementById('hrStatus').innerText = "Starting camera...";
        document.getElementById('sosWarning').innerText = "";

        video.onloadedmetadata = () => {
            video.play();
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            document.getElementById('hrStatus').innerText = "Looking for face... please position your face in the frame.";
            captureFrames();
        };
    } catch (error) {
        console.error("Camera error:", error);
        alert("Could not access camera. Please grant camera permissions.");
        stopHeartRateDetection();
    }
}

async function captureFrames() {
    const video = document.getElementById('hrVideo');
    const canvas = document.getElementById('hrCanvas');
    const ctx = canvas.getContext('2d');

    async function processFrame() {
        if (!hrStream) return;

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        try {
            const predictions = await faceDetectionModel.estimateFaces(video, false);

            if (predictions && predictions.length > 0) {
                faceDetected = true;
                noFaceFrameCount = 0;

                const face = predictions[0];
                const start = face.topLeft;
                const end = face.bottomRight;
                const faceWidth = end[0] - start[0];
                const faceHeight = end[1] - start[1];

                // --- Motion proxy: frame-to-frame displacement of face center ---
                // Cheap, no extra model needed. Logged alongside each reading so
                // motion-related reading failures can be quantified after the
                // fact instead of only described qualitatively.
                const centerX = (start[0] + end[0]) / 2;
                const centerY = (start[1] + end[1]) / 2;
                let motion = 0;
                if (prevFaceCenter) {
                    motion = Math.hypot(centerX - prevFaceCenter.x, centerY - prevFaceCenter.y);
                }
                prevFaceCenter = { x: centerX, y: centerY };

                ctx.strokeStyle = '#00ff00';
                ctx.lineWidth = 3;
                ctx.strokeRect(start[0], start[1], faceWidth, faceHeight);

                const elapsedTotal = (Date.now() - hrStartTime) / 1000;

                const roiX = start[0] + faceWidth * ROI_X0;
                const roiY = start[1] + faceHeight * ROI_Y0;
                const roiW = faceWidth * (ROI_X1 - ROI_X0);
                const roiH = faceHeight * (ROI_Y1 - ROI_Y0);

                ctx.strokeStyle = '#ff00ff';
                ctx.lineWidth = 2;
                ctx.strokeRect(roiX, roiY, roiW, roiH);

                const imageData = ctx.getImageData(
                    Math.max(0, roiX),
                    Math.max(0, roiY),
                    Math.max(1, Math.min(roiW, canvas.width - roiX)),
                    Math.max(1, Math.min(roiH, canvas.height - roiY))
                );

                let rSum = 0, gSum = 0, bSum = 0;
                let pixelCount = 0;
                for (let i = 0; i < imageData.data.length; i += 4) {
                    rSum += imageData.data[i];
                    gSum += imageData.data[i + 1];
                    bSum += imageData.data[i + 2];
                    pixelCount++;
                }

                const nowMs = Date.now();
                rgbSamples.push({ r: rSum / pixelCount, g: gSum / pixelCount, b: bSum / pixelCount,
                                  timestamp: nowMs, motion: motion });
                while (rgbSamples.length > 0 && nowMs - rgbSamples[0].timestamp > SAMPLE_KEEP_S * 1000) {
                    rgbSamples.shift();
                }

                if (elapsedTotal < 2) {
                    document.getElementById('hrStatus').innerText = "Face detected. Calibrating - hold still.";
                } else if (!calibrationComplete) {
                    const calibProgress = Math.min(100, Math.floor((elapsedTotal / CALIBRATION_DURATION) * 100));
                    document.getElementById('hrStatus').innerText =
                        `Calibrating baseline... ${calibProgress}%`;

                    // Cadence gate: one estimate per READING_INTERVAL_MS. (The old
                    // floor(elapsed) % 3 test was true for every frame in a 1 s window,
                    // i.e. ~30 estimates per "reading", which also let the
                    // 3-consecutive-readings anomaly rule fire within ~0.1 s.)
                    if (hasFullWindow() && elapsedTotal * 1000 - lastReadingAtMs >= READING_INTERVAL_MS) {
                        lastReadingAtMs = elapsedTotal * 1000;
                        const calWindow = recentWindow(); // same 15 s window as monitoring / offline evaluation
                        const avgMotionCal = calWindow.reduce((a, r) => a + r.motion, 0) / calWindow.length;
                        const bpm = calculateHeartRate(calWindow);
                        const ok = bpm > 0 && bpm >= MIN_BPM && bpm <= MAX_BPM;
                        if (ok) bpmReadings.push(bpm);
                        logHR({
                            timestamp: new Date().toISOString(),
                            phase: "calibration",
                            status: ok ? "ok" : "no_estimate",
                            bpm: ok ? Math.round(bpm) : "",
                            motion: Math.round(avgMotionCal * 100) / 100,
                            fps_achieved: Math.round(lastAchievedFps * 10) / 10
                        });
                    }

                    if (elapsedTotal >= CALIBRATION_DURATION) {
                        finishCalibration();
                    }
                } else {
                    // --- Post-calibration continuous monitoring ---
                    if (hasFullWindow() && elapsedTotal * 1000 - lastReadingAtMs >= READING_INTERVAL_MS) {
                        lastReadingAtMs = elapsedTotal * 1000;
                        const windowSlice = recentWindow(); // last POS_WINDOW_S seconds
                        const bpm = calculateHeartRate(windowSlice);
                        const avgMotion = windowSlice.reduce((a, r) => a + r.motion, 0) / windowSlice.length;

                        if (bpm > 0 && bpm >= MIN_BPM && bpm <= MAX_BPM) {
                            handleMonitoringReading(bpm, avgMotion);
                        } else {
                            // Failed estimates are logged (with motion) so detection
                            // failures can be quantified, not just successes.
                            logHR({
                                timestamp: new Date().toISOString(),
                                phase: "monitoring",
                                status: "no_estimate",
                                bpm: "",
                                motion: Math.round(avgMotion * 100) / 100,
                                baseline_bpm: baselineBpm,
                                fps_achieved: Math.round(lastAchievedFps * 10) / 10
                            });
                        }
                    }
                }

            } else {
                noFaceFrameCount++;
                if (noFaceFrameCount > MAX_NO_FACE_FRAMES) {
                    document.getElementById('hrStatus').innerText =
                        "Face lost. Please position your face in the frame.";
                    document.getElementById('heartRate').innerText = "--";
                    if (faceDetected) {
                        logHR({
                            timestamp: new Date().toISOString(),
                            phase: "event",
                            status: "face_lost"
                        });
                        rgbSamples = [];
                        faceDetected = false;
                    }
                } else {
                    document.getElementById('hrStatus').innerText =
                        `Looking for face... (${noFaceFrameCount}/${MAX_NO_FACE_FRAMES})`;
                }
            }
        } catch (error) {
            console.error("Face detection error:", error);
        }

        setTimeout(() => {
            hrAnimationFrame = requestAnimationFrame(processFrame);
        }, 33);
    }

    processFrame();
}

// Samples falling in the most recent POS_WINDOW_S seconds.
function recentWindow() {
    if (rgbSamples.length === 0) return [];
    const tEnd = rgbSamples[rgbSamples.length - 1].timestamp;
    let i = rgbSamples.length - 1;
    while (i > 0 && tEnd - rgbSamples[i - 1].timestamp <= POS_WINDOW_S * 1000) i--;
    return rgbSamples.slice(i);
}

// True once the buffer covers (nearly) a full analysis window.
function hasFullWindow() {
    if (rgbSamples.length < 2) return false;
    const span = (rgbSamples[rgbSamples.length - 1].timestamp - rgbSamples[0].timestamp) / 1000;
    return span >= POS_MIN_SPAN_S;
}

// Linear interpolation of one channel onto a uniform grid.
function resampleUniform(samples, key, n, t0, dtMs) {
    const out = new Array(n);
    let j = 0;
    for (let i = 0; i < n; i++) {
        const t = t0 + i * dtMs;
        while (j < samples.length - 2 && samples[j + 1].timestamp < t) j++;
        const a = samples[j], b = samples[j + 1];
        const span = b.timestamp - a.timestamp;
        const w = span > 0 ? Math.min(1, Math.max(0, (t - a.timestamp) / span)) : 0;
        out[i] = a[key] + w * (b[key] - a[key]);
    }
    return out;
}

function meanOf(x) { let s = 0; for (let i = 0; i < x.length; i++) s += x[i]; return s / x.length; }
function stdOf(x) {
    const m = meanOf(x); let s = 0;
    for (let i = 0; i < x.length; i++) s += (x[i] - m) * (x[i] - m);
    return Math.sqrt(s / x.length);
}

// POS (Wang et al., 2017) heart-rate estimate from a window of
// {r, g, b, timestamp, motion} samples. Returns BPM, or 0 if the window is
// too short or numerically unusable. There is NO signal-quality check: any
// usable window yields the strongest spectral peak in 0.7-3.0 Hz, right or wrong.
function calculateHeartRate(samples) {
    if (samples.length < 2) return 0;
    const t0 = samples[0].timestamp;
    const spanS = (samples[samples.length - 1].timestamp - t0) / 1000;
    if (!(spanS >= POS_MIN_SPAN_S)) return 0;
    lastAchievedFps = (samples.length - 1) / spanS;   // logged for transparency

    const fs = POS_RESAMPLE_HZ;
    const n = Math.floor(spanS * fs) + 1;
    const R = resampleUniform(samples, 'r', n, t0, 1000 / fs);
    const G = resampleUniform(samples, 'g', n, t0, 1000 / fs);
    const B = resampleUniform(samples, 'b', n, t0, 1000 / fs);

    // 1) temporal normalisation of each channel by its window mean
    const mR = meanOf(R), mG = meanOf(G), mB = meanOf(B);
    if (!(mR > 0 && mG > 0 && mB > 0)) return 0;

    // 2) POS projection: S1 = G - B, S2 = G + B - 2R, h = S1 + (std S1 / std S2) * S2
    const S1 = new Array(n), S2 = new Array(n);
    for (let i = 0; i < n; i++) {
        const rn = R[i] / mR, gn = G[i] / mG, bn = B[i] / mB;
        S1[i] = gn - bn;
        S2[i] = gn + bn - 2 * rn;
    }
    const sd2 = stdOf(S2);
    if (!(sd2 > 0)) return 0;
    const alpha = stdOf(S1) / sd2;
    const h = new Array(n);
    for (let i = 0; i < n; i++) h[i] = S1[i] + alpha * S2[i];

    // 3) linear detrend (least-squares line removed)
    const tMean = (n - 1) / 2;
    const hMean = meanOf(h);
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) { num += (i - tMean) * (h[i] - hMean); den += (i - tMean) * (i - tMean); }
    const slope = den > 0 ? num / den : 0;
    for (let i = 0; i < n; i++) h[i] = h[i] - (hMean + slope * (i - tMean));

    // 4) Hann window
    for (let i = 0; i < n; i++) h[i] *= 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (n - 1));

    // 5) spectral peak in [POS_FREQ_LO_HZ, POS_FREQ_HI_HZ]. Equivalent to the
    //    magnitude of a zero-padded FFT (length POS_ZERO_PAD * n) evaluated at
    //    the in-band bins only.
    const nfft = POS_ZERO_PAD * n;
    const df = fs / nfft;
    const kLo = Math.ceil(POS_FREQ_LO_HZ / df), kHi = Math.floor(POS_FREQ_HI_HZ / df);
    let bestK = -1, bestPow = -Infinity;
    for (let k = kLo; k <= kHi; k++) {
        const w = (2 * Math.PI * k) / nfft;
        let re = 0, im = 0;
        for (let i = 0; i < n; i++) { re += h[i] * Math.cos(w * i); im -= h[i] * Math.sin(w * i); }
        const pw = re * re + im * im;
        if (pw > bestPow) { bestPow = pw; bestK = k; }
    }
    if (bestK < 0 || !isFinite(bestPow)) return 0;
    return 60 * bestK * df;
}

function finishCalibration() {
    if (bpmReadings.length === 0) {
        // Could not establish a baseline (e.g. poor lighting/motion during
        // calibration). Fall back to the original fixed-window behaviour
        // rather than silently failing.
        document.getElementById('hrStatus').innerText =
            "Could not establish a baseline. Falling back to fixed-threshold mode.";
        calibrationComplete = true;
        baselineBpm = null;
        return;
    }

    baselineBpm = Math.round(
        bpmReadings.reduce((a, b) => a + b) / bpmReadings.length
    );
    dynamicUpperBound = baselineBpm + DYNAMIC_UPPER_OFFSET;
    dynamicLowerBound = Math.max(BAND_FLOOR_BPM, baselineBpm - DYNAMIC_LOWER_OFFSET);
    calibrationComplete = true;
    consecutiveOutOfBand = 0;

    console.log(`Calibration complete. Baseline: ${baselineBpm} BPM, band: [${dynamicLowerBound}, ${dynamicUpperBound}]`);
    document.getElementById('hrStatus').innerText =
        `Calibrated. Baseline ${baselineBpm} BPM (normal band ${dynamicLowerBound}-${dynamicUpperBound}). Monitoring...`;
}

function handleMonitoringReading(bpm, avgMotion) {
    const timestamp = new Date().toISOString();
    document.getElementById('heartRate').innerText = Math.round(bpm);

    // Absolute thresholds are checked first and always win -- this is the
    // conservative, calibration-independent final safety check described
    // in Section 4.4.5 of the paper.
    const absoluteEmergency = bpm >= EMERGENCY_THRESHOLD;
    const absoluteLow = bpm < LOW_BPM_THRESHOLD;

    // Relative/dynamic band check, only meaningful if calibration succeeded.
    let outOfBand = false;
    if (baselineBpm !== null) {
        outOfBand = bpm > dynamicUpperBound || bpm < dynamicLowerBound;
        consecutiveOutOfBand = outOfBand ? consecutiveOutOfBand + 1 : 0;
    }
    const sustainedAnomaly = consecutiveOutOfBand >= SUSTAINED_ANOMALY_READINGS;

    postCalibrationReadings.push({ bpm, motion: avgMotion, timestamp, outOfBand, sustainedAnomaly });
    logHR({
        timestamp,
        phase: "monitoring",
        status: "ok",
        fps_achieved: Math.round(lastAchievedFps * 10) / 10,
        bpm: Math.round(bpm),
        motion: Math.round(avgMotion * 100) / 100,
        baseline_bpm: baselineBpm,
        out_of_band: outOfBand,
        sustained_anomaly: sustainedAnomaly,
        absolute_emergency: absoluteEmergency,
        absolute_low: absoluteLow
    });

    if (absoluteEmergency) {
        triggerEmergencyFlow(bpm, "absolute_threshold");
    } else if (absoluteLow) {
        document.getElementById('sosWarning').innerText = `Low heart rate (${Math.round(bpm)} BPM)`;
        document.getElementById('sosWarning').style.color = "#ffaa00";
    } else if (sustainedAnomaly) {
        triggerEmergencyFlow(bpm, "sustained_dynamic_anomaly");
        consecutiveOutOfBand = 0; // avoid re-firing every reading while still anomalous
    } else {
        document.getElementById('sosWarning').innerText = `Heart rate normal (${Math.round(bpm)} BPM)`;
        document.getElementById('sosWarning').style.color = "#00ff00";
    }
}

// --- Sensor-fusion gate ---
// Called whenever the cardiac module flags an anomaly (absolute or
// sustained-dynamic). If a distress voice keyword was heard recently, we
// treat the two independent signals as corroborating and dispatch
// immediately without a confirmation dialog (dual-modal path in Fig. 3).
// Otherwise we fall back to a 15-second confirmation dialog, matching the
// diagram's ConfirmationDialog -> Timeout/Dismiss -> DirectDispatch/Cancelled.
const ALERT_COOLDOWN_MS = 60000;   // don't re-fire (and re-send SMS) every 3 s while HR stays high
let lastAlertAtMs = -Infinity;

function triggerEmergencyFlow(bpm, reasonCode) {
    const roundedBpm = Math.round(bpm);
    if (Date.now() - lastAlertAtMs < ALERT_COOLDOWN_MS || hrConfirmOpen) {
        logHR({ timestamp: new Date().toISOString(), phase: "event",
                          status: "alert_suppressed_cooldown", bpm: roundedBpm, reason_code: reasonCode });
        return;
    }
    lastAlertAtMs = Date.now();
    document.getElementById('sosWarning').innerText =
        `Heart-rate alert (experimental): ${roundedBpm} BPM is outside the prototype's alert rule (${reasonCode}).`;
    document.getElementById('sosWarning').style.color = "#ff0000";

    const voiceActive = isVoiceFlagActive();
    logHR({
        timestamp: new Date().toISOString(),
        phase: "event",
        status: "alert_triggered",
        bpm: roundedBpm,
        reason_code: reasonCode,
        voice_flag_active: voiceActive,
        path: voiceActive ? "fusion_direct" : "confirmation_dialog"
    });

    if (voiceActive) {
        console.log("Sensor fusion: cardiac anomaly + recent voice flag -> dispatching directly.");
        requestLocation("hr_fusion");
        return;
    }

    // Cardiac-only path: 15 s confirmation window, matches Fig. 3.
    // Uses an in-page, NON-blocking dialog: window.confirm() freezes the page's
    // timers, so a 15 s auto-dispatch timeout could never fire while it was open.
    showHrConfirmation(roundedBpm, 15,
        () => requestLocation("hr_confirmed"),
        () => {
            logHR({ timestamp: new Date().toISOString(), phase: "event", status: "alert_dismissed" });
            document.getElementById('sosWarning').innerText = "Alert dismissed by user.";
            document.getElementById('sosWarning').style.color = "#ffaa00";
        },
        () => {
            console.log("Confirmation countdown elapsed -> dispatching (fail-safe default).");
            logHR({ timestamp: new Date().toISOString(), phase: "event", status: "confirmation_timeout" });
            requestLocation("hr_timeout");
        });
}

let hrConfirmOpen = false;
function showHrConfirmation(bpm, seconds, onSend, onCancel, onTimeout) {
    if (hrConfirmOpen) return;            // one dialog at a time; don't stack alerts
    hrConfirmOpen = true;
    const box = document.createElement('div');
    box.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.75);display:flex;' +
        'align-items:center;justify-content:center;z-index:9999;';
    box.innerHTML =
        '<div style="background:#1e1e1e;color:#fff;padding:24px;border-radius:12px;max-width:340px;text-align:center;">' +
        `<h3 style="margin:0 0 8px;">Heart rate ${bpm} BPM</h3>` +
        '<p style="margin:0 0 12px;">Send emergency SOS?<br>Sends automatically in <b id="hrCountdown"></b> s unless cancelled.</p>' +
        '<button id="hrSendNow" style="margin:4px;padding:8px 14px;">Send now</button>' +
        '<button id="hrCancel" style="margin:4px;padding:8px 14px;">Cancel</button></div>';
    document.body.appendChild(box);
    let left = seconds;
    const span = box.querySelector('#hrCountdown');
    span.textContent = left;
    const close = () => { clearInterval(tick); box.remove(); hrConfirmOpen = false; };
    const tick = setInterval(() => {
        left--;
        span.textContent = left;
        if (left <= 0) { close(); onTimeout(); }
    }, 1000);
    box.querySelector('#hrSendNow').onclick = () => { close(); onSend(); };
    box.querySelector('#hrCancel').onclick = () => { close(); onCancel(); };
}

function showFinalResult() {
    // Retained as the end-of-session summary (used if calibration never
    // completed, matching the original fixed-window behaviour).
    if (hrAnimationFrame) {
        cancelAnimationFrame(hrAnimationFrame);
        hrAnimationFrame = null;
    }

    if (!faceDetected || (bpmReadings.length === 0 && postCalibrationReadings.length === 0)) {
        document.getElementById('hrStatus').innerText =
            "Unable to measure. No face detected or insufficient data.";
        document.getElementById('heartRate').innerText = "--";
        document.getElementById('sosWarning').innerText =
            "Please ensure your face is clearly visible and try again.";
        return;
    }

    const allBpms = postCalibrationReadings.length > 0
        ? postCalibrationReadings.map(r => r.bpm)
        : bpmReadings;
    const finalBpm = Math.round(allBpms.reduce((a, b) => a + b) / allBpms.length);

    document.getElementById('heartRate').innerText = finalBpm;
    document.getElementById('hrStatus').innerText =
        `Session ended (${allBpms.length} readings averaged).`;

    console.log(`Final BPM: ${finalBpm}`);
}

// Manual reference-device reading, entered by a second person during a
// validation session (e.g. from a pulse oximeter run in parallel). Paired
// with the app's own most recent reading so a real MAE / Bland-Altman
// comparison can be computed later -- see the CSV export.
function recordReferenceReading() {
    const input = document.getElementById('referenceBpmInput');
    if (!input) return;
    const refValue = parseFloat(input.value);
    if (isNaN(refValue) || refValue <= 0) {
        alert("Enter a valid reference BPM value first.");
        return;
    }
    const lastAppReading = postCalibrationReadings.length > 0
        ? postCalibrationReadings[postCalibrationReadings.length - 1].bpm
        : (bpmReadings.length > 0 ? bpmReadings[bpmReadings.length - 1] : null);

    referenceBpmLog.push({
        ...hrContext(),
        timestamp: new Date().toISOString(),
        app_bpm: lastAppReading !== null ? Math.round(lastAppReading) : "",
        reference_bpm: refValue
    });
    input.value = "";
    alert("Reference reading recorded.");
}

function exportHRSessionData() {
    const rows = sessionLog.map(r => ({ ...r, source: "session_log" }));
    const refRows = referenceBpmLog.map(r => ({ ...r, source: "reference_log" }));
    downloadCSV([...rows, ...refRows], "hr_session_data.csv");
}

// Generic CSV export helper used by all three "export" buttons.
function downloadCSV(rows, filename) {
    if (!rows || rows.length === 0) {
        alert("No data recorded yet for this session.");
        return;
    }
    const headers = Array.from(
        rows.reduce((set, row) => {
            Object.keys(row).forEach(k => set.add(k));
            return set;
        }, new Set())
    );
    const csvLines = [headers.join(",")];
    rows.forEach(row => {
        const line = headers.map(h => {
            const val = row[h] === undefined ? "" : String(row[h]).replace(/"/g, '""');
            return `"${val}"`;
        }).join(",");
        csvLines.push(line);
    });
    const blob = new Blob([csvLines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function stopHeartRateDetection() {
    const video = document.getElementById('hrVideo');
    const resultsDiv = document.getElementById('healthResults');
    const startBtn = document.getElementById('startHRBtn');
    const stopBtn = document.getElementById('stopHRBtn');

    if (hrStream) {
        hrStream.getTracks().forEach(track => track.stop());
        hrStream = null;
    }

    if (hrAnimationFrame) {
        cancelAnimationFrame(hrAnimationFrame);
        hrAnimationFrame = null;
    }

    showFinalResult();

    video.srcObject = null;
    video.style.display = "none";
    startBtn.style.display = "block";
    stopBtn.style.display = "none";

    rgbSamples = [];
    faceDetected = false;
}
