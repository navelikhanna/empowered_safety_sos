These files are earlier prototypes that are NOT part of the current running
system and are kept here only for reference:

- sos.js — an alternate Node/Express backend that was never wired to the
  frontend (script.js only ever calls the Flask backend on port 5000).
- new/voice.pde, new/voice.html — an early Processing-based voice prototype.
  script.js contains a comment confirming this path was abandoned:
  "// REMOVED: fetch to port 8080 - it was broken and unnecessary"

Do not run these; they are not part of the reproducible system described in
the paper.
