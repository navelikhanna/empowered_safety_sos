## Final submission merge
- `validation/evaluate_ubfc.py` is now the POS evaluation script (`--method pos --split test`) that produced the paper's tables; the old red-channel script is `validation/evaluate_ubfc_legacy.py` (LEGACY, used by `evaluate_mcd.py`).
- Single merged repository: POS app + tests, `analyze_logs.py`, `rppg_core.py` (POS port, checked against `script.js` by `tests/crosscheck_js_python.py`).
- The synthetic experiment and MCD tools still simulate/evaluate the replaced red-channel estimator (LEGACY); they are not used in the paper.

# Review round 3 (heart rate): red-channel peak detector replaced by POS

The red-channel estimator was replaced after the offline UBFC-rPPG evaluation
(10 development subjects; 32 held-out test subjects, run once, frozen).

Frozen method (`script.js::calculateHeartRate`, mirrored by
`validation/rppg_core.py::calculate_heart_rate_pos`):
- ROI x 15-85 %, y 30-85 % of the BlazeFace box (was a forehead box)
- mean R, G, B per frame; irregular browser timestamps resampled to 30 Hz
- POS projection over a 15 s window, one estimate every 3 s
- linear detrend, Hann window, spectral peak in 0.7-3.0 Hz (42-180 BPM),
  spectrum evaluated at 8x the window length (zero-padding)

Consequences:
- First reading appears after ~15 s (calibration still lasts 30 s).
- POS never returns "no estimate" and has no quality check; a bad window gives
  a confident wrong value (83 of 564 test windows were false alerts under the
  absolute rule). Treat the heart-rate alert as advisory.
- Successive windows overlap by 80 %, so "3 consecutive readings" spans ~21 s
  of signal, not 9 s of independent data.
- Alert rules, fusion gate, 15 s countdown, 60 s cooldown: unchanged.
- On-screen alert text now reads "Heart-rate alert (experimental)".
- Session metadata row now logs the POS constants.
- `tests/crosscheck_js_python.py` now cross-checks the POS estimator
  (193 synthetic windows incl. jittered timing: max |JS - Python| = 0.000 BPM).
- LEGACY (still red-channel; do not report their numbers for the app):
  `validation/evaluate_ubfc.py`, `evaluate_mcd.py`, `synthetic_motion_experiment.py`.

---

# Implementation changes (review round 2)

## Bugs fixed (found while preparing the changes)
1. **HR above ~112 BPM was unreachable.** The fixed 15-sample refractory gap
   made 130 BPM read as ~65 (every other beat), so the >=130 absolute
   threshold could never fire. Smoothing and gap are now defined in seconds
   (0.10 s / 0.33 s) and converted with the frame rate.
2. **BPM assumed 30 FPS.** The browser loop usually runs slower, which
   biased BPM (about +/-30 BPM at 20 FPS in tests). BPM now uses the
   measured frame rate of each window; `fps_achieved` is logged.
3. **Reading cadence.** `Math.floor(elapsed) % 3 === 0` was true for every
   frame in a one-second window, so "3 consecutive out-of-band readings"
   could fire within ~0.1 s. Readings are now gated to one per 3 s.
4. **Blocking dialogs defeated the 15 s auto-dispatch.** `confirm()` freezes
   timers, and `requestLocation()` asked for a second `confirm()`. The
   cardiac path now uses a non-blocking countdown dialog; automatic paths no
   longer wait on `confirm()` / `alert()`.
5. **Repeat firing.** A 60 s cooldown prevents re-sending SMS every reading
   while HR stays high.
6. `redValues` was unbounded on long sessions; now trimmed.
7. Flask `debug=True` is now off unless `FLASK_DEBUG=1`.

## Added for reviewer concerns
- Geolocation: `position.coords.accuracy` and fix time logged per dispatch.
- SOS log: trigger source, server latency, network info, `run_metadata.json`.
- HR log: failed estimates, motion, alert path/events, achieved FPS.
- Voice log: session / speaker / noise condition, recognizer errors, confidence.
- `validation/`: UBFC-rPPG evaluation, per-subject errors, Bland-Altman,
  motion split, and parameter sensitivity sweep.
- "Alert Nearest Police" button labelled as not implemented.
- Backend URL configurable via `window.SOS_API_BASE`.

## Deviation to be aware of
Changes 1-3 alter the HR algorithm relative to earlier versions
(constants 5 / 15 samples -> 0.10 s / 0.33 s). To reproduce the old
behaviour in the evaluation, run `evaluate_ubfc.py --legacy-params`.

---

# Implementation changes (review round 3)

Targets the implementation-side points of round-2 Reviewer 3 (voice trial
independence / representativeness) and Reviewer 4 (items 1-4, 8-9, 11).

## New evidence tooling
- `validation/rppg_core.py` - the estimator + alert logic as a dependency-free
  module; `evaluate_ubfc.py` now imports it (no duplicated copy to drift).
- `tests/crosscheck_js_python.py` + `tests/js_hr_harness.js` - runs the REAL
  `script.js` `calculateHeartRate()` under Node and checks it equals the Python
  port (R4-4/R4-1: the offline evaluation really is the shipped algorithm). Also
  shows the old 5/15-sample constants read 130 BPM as ~65.
- `validation/synthetic_motion_experiment.py` - controlled simulation of
  false-negative / false-positive behaviour of the full alert logic vs motion
  artefact strength (R4-2, R4-11). Simulation only; label it as such.
- `validation/evaluate_ubfc.py` now also replays the full alert logic
  (calibration baseline, dynamic band, 3-in-a-row, >=130) on each UBFC subject
  -> `alert_replay.csv`, unjustified alerts per hour (R4-11).
- `validation/analyze_logs.py` - computes everything from the exported CSVs:
  success-rate Wilson CI, latency mean/SD/median/min/max, voice accuracy per
  condition x keyword with Wilson CI, session-cluster bootstrap CI, false-trigger
  rate on negative controls, HR-vs-reference MAE/bias/limits of agreement per
  condition, and real geolocation error vs a surveyed point (R4-3, R4-9, R3-3).
- `tests/test_server.py` - mocked-Twilio backend tests: every trigger source
  reaches the same dispatch path and is logged; bad input rejected (R4-8; this
  is a software test, not a cross-browser field validation).

## Front-end logging additions
- Voice: "intended keyword" selector incl. a negative control ("none") ->
  `expected_keyword` column, so accuracy, confusability and false positives are
  measurable (R3 round 1 control + R3-3 independence).
- HR: subject ID, condition, face-camera distance and lux are stamped on every
  log row and on reference readings; a `metadata` row records user agent, camera
  label, granted resolution/frame-rate setting, BlazeFace options and algorithm
  constants (R4-4 reproducibility).
- BlazeFace loaded with explicit `{maxFaces: 1, scoreThreshold: 0.75}`.
- Calibration estimates use the same rolling 150-sample window as monitoring and
  the offline evaluation (previously the window grew to the whole calibration so
  far). Small behavioural change.
- Automatic SOS paths no longer use `alert()` when no contact is saved.

## Backend hardening
- CORS restricted to the local front-end origins (was open to any website).
- Server-side E.164 and coordinate validation (rejected requests are logged).
- `SOS_LOG_DIR`, `SERVER_LOCATION`, `NETWORK_NOTE` env vars; written to
  `run_metadata.json` for the latency experiment (R4-4).

## MCD-rPPG support (added after round 3)
- `validation/evaluate_mcd.py` + `validation/download_mcd_subset.py`: evaluate the same estimator on
  the open (CC-BY-4.0) MCD-rPPG dataset with rest vs post-exercise conditions and a PPG-derived
  reference HR; per-condition MAE/bias/limits of agreement, per-recording MAE CI, alert replay.
- `evaluate_ubfc.py`: `extract_signal` gained optional `start_s`, `max_seconds`, `max_width`
  (defaults unchanged); new `video_info()` helper.
- Not run on the real files by us; see validation/README.md for the two assumptions to check.

