# Empowered Safety

Browser-based personal safety prototype: SOS/SMS dispatch, voice-activated
alerts, and camera-based heart-rate anomaly screening. No client-side
install and no dedicated hardware; SMS dispatch needs the self-hosted
Flask/Twilio backend below.

## Setup

1. **Backend**
   ```bash
   pip install -r requirements.txt
   cp .env.example .env
   # edit .env with your real Twilio Account SID, Auth Token, and phone number
   python sos_server.py
   ```
   The Flask server listens on `http://127.0.0.1:5000`.

2. **Frontend**
   The frontend must be served over HTTP (not opened as a `file://` URL),
   since `getUserMedia` (camera/mic) and `SpeechRecognition` require a
   secure context in most browsers:
   ```bash
   python -m http.server 8000
   ```
   Then open `http://127.0.0.1:8000/index.html`.

3. Add at least one emergency contact (E.164 format, e.g. `+919876543210`)
   before testing SOS dispatch.

## Project structure

- `index.html`, `styles.css`, `script.js` — frontend (contacts, SOS, voice
  activation, heart-rate monitor with calibration/dynamic-threshold/
  sensor-fusion logic)
- `sos_server.py` — Flask backend; dispatches SMS via Twilio, logs every
  attempt to `sessions/sos_dispatch_log.csv`
- `validation/` — offline evaluation of the rPPG algorithm on the public UBFC-rPPG dataset (see `validation/README.md`)
- `ppg_detector.py` — standalone OpenCV/finger-based PPG prototype, **not**
  used by the browser app; kept for reference only
- `archive/` — earlier prototypes not part of the current system (see
  `archive/README.md`)

## Data export for validation / statistics

The frontend logs every trial to memory during a session and can export CSV:
- **Heart-rate module:** "Download session data (CSV)" exports every BPM
  attempt (calibration and monitoring), including failed estimates
  (`status=no_estimate`), motion score, achieved frame rate, calibration
  baseline, alert events (`alert_triggered`, `fusion_direct` vs
  `confirmation_dialog`, `confirmation_timeout`, `alert_dismissed`,
  `face_lost`) and any manually entered reference readings.
- **Voice module:** "Download voice trial log (CSV)" exports every trial with
  `session_id`, `speaker_id`, `noise_condition`, transcript, recognizer
  confidence and matched keyword. Recognition errors are logged as
  `error:<reason>`, so failed trials are not silently dropped.
- **SOS module:** "Download SOS dispatch log (CSV)" exports per dispatch:
  `trigger_source` (manual / voice / hr_fusion / hr_confirmed / hr_timeout),
  client and server latency, browser-reported geolocation accuracy radius
  (`geo_accuracy_m`), time to obtain the fix, and network info where the
  browser exposes it. The server writes the same fields to
  `sessions/sos_dispatch_log.csv` and the software environment to
  `sessions/run_metadata.json`.

`geo_accuracy_m` is the radius the browser *claims*, not measured error.

## Heart-rate validation

Validation uses the public UBFC-rPPG dataset (DATASET_2), not volunteer
recordings. The app estimates heart rate with the POS method (central-face RGB,
15 s window stepped every 3 s, linear detrend, Hann window, spectral peak in
0.7-3.0 Hz). Results in the paper: 10 development subjects, then 32 held-out
test subjects evaluated once with the method frozen.

`validation/rppg_core.py` holds the Python port of the shipped estimator
(`calculate_heart_rate_pos`). **`validation/evaluate_ubfc.py` is the script that produced the
paper's tables** (`--method pos --split test`). `evaluate_ubfc_legacy.py`, `evaluate_mcd.py`
and `synthetic_motion_experiment.py` evaluate the replaced red-channel
method and are marked LEGACY in their headers; do not report their numbers for the app.
Dataset layout: `data/README.md`. See `validation/README.md`.

## Tests and analysis

```bash
python -m unittest tests.test_server -v          # backend with Twilio mocked (no SMS sent)
python tests/crosscheck_js_python.py             # script.js POS estimator == Python POS port (needs Node)
cd validation
python analyze_logs.py --sos ... --voice ... --hr ...      # statistics from exported CSVs
python synthetic_motion_experiment.py --n 100              # LEGACY (red-channel) simulated stress test
```

When collecting trials, fill the testing-tools fields first: speaker ID, noise
condition and **intended keyword** (use "none" for negative controls) for voice;
subject ID, condition, face-camera distance and lux for heart rate. These are
written into every log row.

The backend only accepts requests from the local front-end origins
(`127.0.0.1`/`localhost` on ports 8000 and 5500). Serving the front-end from
elsewhere? Set `ALLOWED_ORIGINS` in `.env`.

## Known limitations (see paper, Section 6)

- Backend must currently be self-hosted (no public deployment yet).
- Voice recognition uses the browser's cloud speech service in Chromium
  browsers, not on-device processing.
- Heart-rate estimation is evaluated offline on UBFC-rPPG (lab video with a
  pulse-oximeter reference). It has not been tested for real emergency
  detection, motion/distress, or in-browser webcam conditions.
- The 130 / 60 BPM and dynamic-band thresholds are prototype heuristics, not
  clinically validated criteria.
- "Alert Nearest Police" is a placeholder; no real emergency-services API is
  called.
